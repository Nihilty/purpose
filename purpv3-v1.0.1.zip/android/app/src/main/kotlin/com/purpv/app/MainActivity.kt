package com.purpv.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
