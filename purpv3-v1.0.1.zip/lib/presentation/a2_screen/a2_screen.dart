import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/presentation/homeone_page/homeone_page.dart';import 'package:purpv3/presentation/homepage_page/homepage_page.dart';import 'package:purpv3/widgets/custom_bottom_bar.dart';import 'package:purpv3/widgets/custom_outlined_button.dart';
// ignore_for_file: must_be_immutable
class A2Screen extends StatelessWidget {A2Screen({Key? key}) : super(key: key);

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 18.h), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [SizedBox(height: 18.v), CustomImageView(imagePath: ImageConstant.imgRectangle330, height: 179.v, width: 375.h), SizedBox(height: 49.v), Container(width: 304.h, margin: EdgeInsets.only(left: 35.h, right: 37.h), child: Text("At the end of the assessment you will be provided with your Mental Health Quotient (MHQ) and can request a free detailed report to be emailed to you.\n\nBy completing this assessment you will discover more about your mental wellbeing including your strengths and challenges and will be provided with guidance and resources to help and support you.", maxLines: 13, overflow: TextOverflow.ellipsis, style: CustomTextStyles.bodyLargeLight)), SizedBox(height: 22.v), CustomOutlinedButton(height: 59.v, width: 125.h, text: "Lets go!", buttonStyle: CustomButtonStyles.outlinePrimary, buttonTextStyle: CustomTextStyles.titleLargeInter, onPressed: () {onTapLetsGo(context);})])), bottomNavigationBar: Padding(padding: EdgeInsets.only(left: 17.h, right: 22.h), child: _buildBottomBarSection(context)))); } 
/// Section Widget
Widget _buildBottomBarSection(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.Home: return AppRoutes.homeonePage; case BottomBarEnum.Career: return AppRoutes.homepagePage; case BottomBarEnum.Chat: return "/"; case BottomBarEnum.Me: return "/"; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.homeonePage: return HomeonePage(); case AppRoutes.homepagePage: return HomepagePage(); default: return DefaultWidget();} } 
/// Navigates to the a3Screen when the action is triggered.
onTapLetsGo(BuildContext context) { Navigator.pushNamed(context, AppRoutes.a3Screen); } 
 }
