import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/custom_elevated_button.dart';

class PageoneScreen extends StatelessWidget {
  const PageoneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 88.h,
            vertical: 35.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 77.v),
              Text(
                "PURPOSE",
                style: CustomTextStyles.displaySmallBold,
              ),
              Spacer(),
              CustomImageView(
                imagePath: ImageConstant.imgLogoPrimary,
                height: 305.v,
                width: 226.h,
                margin: EdgeInsets.only(left: 10.h),
              ),
              SizedBox(height: 84.v),
              Container(
                width: 203.h,
                margin: EdgeInsets.only(
                  left: 11.h,
                  right: 21.h,
                ),
                child: Text(
                  "A Journey of Self Discovery",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: CustomTextStyles.titleLargePrimary22_1,
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildGetStartedButton(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildGetStartedButton(BuildContext context) {
    return CustomElevatedButton(
      height: 70.v,
      text: "Get started",
      margin: EdgeInsets.only(
        left: 51.h,
        right: 49.h,
        bottom: 36.v,
      ),
      buttonStyle: CustomButtonStyles.fillGray,
      buttonTextStyle: CustomTextStyles.titleMediumPrimary17,
    );
  }
}
