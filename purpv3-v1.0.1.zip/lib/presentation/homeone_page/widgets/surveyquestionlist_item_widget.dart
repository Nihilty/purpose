import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/custom_elevated_button.dart';

// ignore: must_be_immutable
class SurveyquestionlistItemWidget extends StatelessWidget {
  const SurveyquestionlistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 22.h,
        vertical: 13.v,
      ),
      decoration: AppDecoration.fillGreenA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 12.v),
          Container(
            width: 244.h,
            margin: EdgeInsets.only(
              left: 9.h,
              right: 13.h,
            ),
            child: Text(
              "Do you fancy a foreign degree?",
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: CustomTextStyles.titleLargeInterPrimarySemiBold,
            ),
          ),
          SizedBox(height: 19.v),
          Padding(
            padding: EdgeInsets.only(right: 3.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: CustomElevatedButton(
                    height: 59.v,
                    text: "Yes",
                    margin: EdgeInsets.only(right: 7.h),
                    buttonStyle: CustomButtonStyles.fillWhiteA,
                    buttonTextStyle:
                        CustomTextStyles.titleLargeInterPrimary21_1,
                  ),
                ),
                Expanded(
                  child: CustomElevatedButton(
                    height: 59.v,
                    text: "No",
                    margin: EdgeInsets.only(left: 7.h),
                    buttonStyle: CustomButtonStyles.fillWhiteA,
                    buttonTextStyle:
                        CustomTextStyles.titleLargeInterPrimary21_1,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 16.v),
          Text(
            "Done",
            style: CustomTextStyles.titleLargeInterPrimary21_1,
          ),
        ],
      ),
    );
  }
}
