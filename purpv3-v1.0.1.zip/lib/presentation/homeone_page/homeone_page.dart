import '../homeone_page/widgets/surveyquestionlist_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore_for_file: must_be_immutable
class HomeonePage extends StatelessWidget {
  const HomeonePage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: 375.h,
          decoration: AppDecoration.outlineWhiteA,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 34.v),
              _buildSurveyQuestionList(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildSurveyQuestionList(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 31.h),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            height: 24.v,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return SurveyquestionlistItemWidget();
        },
      ),
    );
  }
}
