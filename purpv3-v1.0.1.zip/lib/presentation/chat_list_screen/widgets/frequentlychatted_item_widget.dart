import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore: must_be_immutable
class FrequentlychattedItemWidget extends StatelessWidget {
  const FrequentlychattedItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 86.h,
      child: Text(
        "Frequently chatted",
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: CustomTextStyles.titleMediumPrimaryMedium,
      ),
    );
  }
}
