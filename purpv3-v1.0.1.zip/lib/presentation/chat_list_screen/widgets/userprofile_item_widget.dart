import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore: must_be_immutable
class UserprofileItemWidget extends StatelessWidget {
  UserprofileItemWidget({
    Key? key,
    this.onTapUserProfile,
  }) : super(
          key: key,
        );

  VoidCallback? onTapUserProfile;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTapUserProfile!.call();
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 6.h,
          vertical: 4.v,
        ),
        decoration: AppDecoration.fillPrimary1.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder27,
        ),
        child: Row(
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgUnsplashIni8gnms190,
              height: 49.adaptSize,
              width: 49.adaptSize,
              radius: BorderRadius.circular(
                24.h,
              ),
              margin: EdgeInsets.only(top: 1.v),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 5.h,
                top: 8.v,
                bottom: 8.v,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 2.h),
                    child: Text(
                      "Anime Man",
                      style: theme.textTheme.labelLarge,
                    ),
                  ),
                  Opacity(
                    opacity: 0.7,
                    child: Text(
                      "ekamcy@gmail.com",
                      style: CustomTextStyles.bodySmallPrimary10,
                    ),
                  ),
                ],
              ),
            ),
            Spacer(),
            Padding(
              padding: EdgeInsets.only(
                top: 8.v,
                right: 8.h,
                bottom: 8.v,
              ),
              child: Column(
                children: [
                  Text(
                    "08:43",
                    style: CustomTextStyles.bodySmallWhiteA70010,
                  ),
                  SizedBox(height: 1.v),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      width: 17.adaptSize,
                      margin: EdgeInsets.only(right: 3.h),
                      padding: EdgeInsets.symmetric(
                        horizontal: 6.h,
                        vertical: 1.v,
                      ),
                      decoration: AppDecoration.fillPrimary.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder7,
                      ),
                      child: Text(
                        "3",
                        style: theme.textTheme.labelSmall,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
