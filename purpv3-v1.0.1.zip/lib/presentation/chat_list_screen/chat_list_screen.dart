import '../chat_list_screen/widgets/frequentlychatted_item_widget.dart';import '../chat_list_screen/widgets/userprofile_item_widget.dart';import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_search_view.dart';
// ignore_for_file: must_be_immutable
class ChatListScreen extends StatelessWidget {ChatListScreen({Key? key}) : super(key: key);

TextEditingController searchController = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 3.h, vertical: 23.v), child: Column(mainAxisSize: MainAxisSize.min, children: [SizedBox(height: 36.v), Text("Community", style: CustomTextStyles.titleMediumPrimary), SizedBox(height: 22.v), Padding(padding: EdgeInsets.symmetric(horizontal: 39.h), child: CustomSearchView(controller: searchController, hintText: "Type here to search", borderDecoration: SearchViewStyleHelper.outlinePrimaryTL29)), SizedBox(height: 25.v), _buildFrequentlyChatted(context), SizedBox(height: 28.v), Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.only(left: 18.h), child: Text("All Messages", style: CustomTextStyles.titleSmallPrimary))), SizedBox(height: 9.v), _buildUserProfile(context)])))); } 
/// Section Widget
Widget _buildFrequentlyChatted(BuildContext context) { return Padding(padding: EdgeInsets.symmetric(horizontal: 18.h), child: ListView.separated(physics: NeverScrollableScrollPhysics(), shrinkWrap: true, separatorBuilder: (context, index) {return SizedBox(height: 1.v);}, itemCount: 2, itemBuilder: (context, index) {return FrequentlychattedItemWidget();})); } 
/// Section Widget
Widget _buildUserProfile(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 12.h), child: ListView.separated(physics: NeverScrollableScrollPhysics(), shrinkWrap: true, separatorBuilder: (context, index) {return SizedBox(height: 17.v);}, itemCount: 9, itemBuilder: (context, index) {return UserprofileItemWidget(onTapUserProfile: () {onTapUserProfile(context);});})); } 
/// Navigates to the chatScreen when the action is triggered.
onTapUserProfile(BuildContext context) { Navigator.pushNamed(context, AppRoutes.chatScreen); } 
 }
