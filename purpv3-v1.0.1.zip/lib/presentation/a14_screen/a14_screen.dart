import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/presentation/homeone_page/homeone_page.dart';import 'package:purpv3/presentation/homepage_page/homepage_page.dart';import 'package:purpv3/widgets/custom_bottom_bar.dart';import 'package:purpv3/widgets/custom_outlined_button.dart';
// ignore_for_file: must_be_immutable
class A14Screen extends StatelessWidget {A14Screen({Key? key}) : super(key: key);

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 34.h), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [SizedBox(height: 13.v), SizedBox(width: 343.h, child: Text("The assessment will now ask you about how different elements of your mental functioning influence your ability to operate in daily life.\n\nPlease choose your answers based on your current perception of yourself.\nPlease respond to all questions and answer honestly in order to get an accurate assessment.\n\nTake time to familiarize yourself with the scale before answering.", maxLines: 13, overflow: TextOverflow.ellipsis, style: CustomTextStyles.bodyLargeLight)), SizedBox(height: 58.v), CustomImageView(imagePath: ImageConstant.imgRectangle341, height: 87.v, width: 339.h), SizedBox(height: 79.v), CustomOutlinedButton(height: 59.v, width: 160.h, text: "continue", buttonStyle: CustomButtonStyles.outlinePrimary, buttonTextStyle: CustomTextStyles.titleLargeInter, onPressed: () {onTapContinue(context);})])), bottomNavigationBar: Padding(padding: EdgeInsets.only(left: 17.h, right: 22.h), child: _buildBottomBarSection(context)))); } 
/// Section Widget
Widget _buildBottomBarSection(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.Home: return AppRoutes.homeonePage; case BottomBarEnum.Career: return AppRoutes.homepagePage; case BottomBarEnum.Chat: return "/"; case BottomBarEnum.Me: return "/"; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.homeonePage: return HomeonePage(); case AppRoutes.homepagePage: return HomepagePage(); default: return DefaultWidget();} } 
/// Navigates to the a15Screen when the action is triggered.
onTapContinue(BuildContext context) { Navigator.pushNamed(context, AppRoutes.a15Screen); } 
 }
