import '../homeone_two_screen/widgets/questionnaire_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';
import 'package:purpv3/widgets/custom_text_form_field.dart';

class HomeoneTwoScreen extends StatelessWidget {
  HomeoneTwoScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController homeOneTwoLanguageEditTextController =
      TextEditingController();

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: 375.h,
          padding: EdgeInsets.symmetric(
            horizontal: 32.h,
            vertical: 28.v,
          ),
          child: Column(
            children: [
              SizedBox(height: 6.v),
              _buildQuestionnaire(context),
              SizedBox(height: 24.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgCarbonQuery,
                      height: 45.adaptSize,
                      width: 45.adaptSize,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 1.h,
                        top: 7.v,
                        bottom: 11.v,
                      ),
                      child: Text(
                        "Queries?",
                        style: CustomTextStyles.titleLargeInterPrimary21_1,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 19.v),
              _buildHomeOneTwoLanguageEditText(context),
              SizedBox(height: 28.v),
              _buildHomeOneTwoSubmitButton(context),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildQuestionnaire(BuildContext context) {
    return ListView.separated(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      separatorBuilder: (
        context,
        index,
      ) {
        return SizedBox(
          height: 24.v,
        );
      },
      itemCount: 2,
      itemBuilder: (context, index) {
        return QuestionnaireItemWidget();
      },
    );
  }

  /// Section Widget
  Widget _buildHomeOneTwoLanguageEditText(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 8.h,
        right: 13.h,
      ),
      child: CustomTextFormField(
        controller: homeOneTwoLanguageEditTextController,
        hintText: "#######",
        hintStyle: CustomTextStyles.titleLargeInterPrimary21,
        textInputAction: TextInputAction.done,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 19.h,
          vertical: 12.v,
        ),
        borderDecoration: TextFormFieldStyleHelper.outlinePrimary,
        fillColor: appTheme.whiteA700,
      ),
    );
  }

  /// Section Widget
  Widget _buildHomeOneTwoSubmitButton(BuildContext context) {
    return CustomOutlinedButton(
      height: 59.v,
      width: 125.h,
      text: "Submit",
      buttonStyle: CustomButtonStyles.outlinePrimary,
      buttonTextStyle: CustomTextStyles.titleLargeInter,
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
