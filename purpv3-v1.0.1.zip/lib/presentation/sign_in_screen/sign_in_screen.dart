import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class SignInScreen extends StatelessWidget {SignInScreen({Key? key}) : super(key: key);

TextEditingController userNameController = TextEditingController();

TextEditingController passwordController = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 27.h, vertical: 16.v), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(height: 34.v), Align(alignment: Alignment.center, child: Text("PURPOSE", style: theme.textTheme.displaySmall)), SizedBox(height: 17.v), CustomImageView(imagePath: ImageConstant.imgArrowLeft, height: 20.v, width: 11.h, margin: EdgeInsets.only(left: 2.h), onTap: () {onTapImgArrowLeft(context);}), SizedBox(height: 36.v), Text("Sign In", style: CustomTextStyles.titleLargePrimaryBlack), SizedBox(height: 5.v), Opacity(opacity: 0.7, child: Text("Enter your credentials", style: CustomTextStyles.titleMediumPrimaryMedium16_3)), SizedBox(height: 18.v), Opacity(opacity: 0.7, child: Text("Username", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), CustomTextFormField(controller: userNameController), SizedBox(height: 11.v), Opacity(opacity: 0.7, child: Text("Password", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), CustomTextFormField(controller: passwordController, textInputAction: TextInputAction.done, obscureText: true, borderDecoration: TextFormFieldStyleHelper.fillGray), SizedBox(height: 13.v), Align(alignment: Alignment.centerRight, child: Opacity(opacity: 0.7, child: GestureDetector(onTap: () {onTapTxtForgotPassword(context);}, child: Padding(padding: EdgeInsets.only(right: 8.h), child: Text("Forgot Password?", style: CustomTextStyles.titleSmallOnPrimary_1))))), Spacer(), CustomElevatedButton(text: "Next", margin: EdgeInsets.only(left: 19.h, right: 20.h), alignment: Alignment.center), SizedBox(height: 38.v), Container(width: 185.h, margin: EdgeInsets.only(left: 74.h), child: RichText(text: TextSpan(children: [TextSpan(text: "Already have an account? ", style: CustomTextStyles.titleSmallff000000), TextSpan(text: "Sign Up", style: CustomTextStyles.titleSmallff000000Bold.copyWith(decoration: TextDecoration.underline))]), textAlign: TextAlign.left))])))); } 

/// Navigates back to the previous screen.
onTapImgArrowLeft(BuildContext context) { Navigator.pop(context); } 
/// Navigates to the forgotPasswordScreen when the action is triggered.
onTapTxtForgotPassword(BuildContext context) { Navigator.pushNamed(context, AppRoutes.forgotPasswordScreen); } 
 }
