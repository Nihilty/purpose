import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/app_bar/appbar_title.dart';
import 'package:purpv3/widgets/app_bar/appbar_trailing_image.dart';
import 'package:purpv3/widgets/app_bar/custom_app_bar.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_elevated_button.dart';
import 'package:purpv3/widgets/custom_switch.dart';

class ProfileOneScreen extends StatelessWidget {
  ProfileOneScreen({Key? key})
      : super(
          key: key,
        );

  bool isSelectedSwitch = false;

  bool isSelectedSwitch1 = false;

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: 375.h,
          padding: EdgeInsets.symmetric(vertical: 22.v),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 43.v),
              Padding(
                padding: EdgeInsets.only(left: 22.h),
                child: Text(
                  "Dashboard",
                  style: CustomTextStyles.headlineLargeInterPrimary,
                ),
              ),
              SizedBox(height: 15.v),
              _buildDashboard(context),
              SizedBox(height: 37.v),
              Padding(
                padding: EdgeInsets.only(left: 30.h),
                child: Text(
                  "My Activities ",
                  style: CustomTextStyles.headlineLargeInterPrimary,
                ),
              ),
              SizedBox(height: 26.v),
              Padding(
                padding: EdgeInsets.only(left: 30.h),
                child: Text(
                  "Articles read",
                  style: CustomTextStyles.titleLargeInterPrimaryBold,
                ),
              ),
              SizedBox(height: 2.v),
              _buildContinue(context),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 106.v,
      title: AppbarTitle(
        text: "Hi, Charlie!",
        margin: EdgeInsets.only(
          left: 18.h,
          top: 22.v,
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgSettingsPrimary56x57,
          margin: EdgeInsets.only(
            left: 39.h,
            right: 39.h,
            bottom: 5.v,
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildDashboard(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.h),
      padding: EdgeInsets.symmetric(vertical: 21.v),
      decoration: AppDecoration.outlinePrimaryContainer1.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder30,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: 13.v,
              bottom: 4.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "My Goals ",
                  style: CustomTextStyles.headlineLargeInterWhiteA700,
                ),
                SizedBox(height: 5.v),
                Text(
                  "For Today",
                  style: CustomTextStyles.titleLargeInterWhiteA700,
                ),
                SizedBox(height: 22.v),
                Text(
                  "4 Out of 6 completed",
                  style: CustomTextStyles.labelMediumInterWhiteA70010,
                ),
              ],
            ),
          ),
          SizedBox(
            height: 120.adaptSize,
            width: 120.adaptSize,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "76%",
                    style: CustomTextStyles.titleLargeInterWhiteA700,
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: SizedBox(
                    height: 120.adaptSize,
                    width: 120.adaptSize,
                    child: CircularProgressIndicator(
                      value: 0.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildContinue(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: IntrinsicWidth(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 10.v),
                decoration: AppDecoration.outlinePrimaryContainer2.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder20,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 7.v),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Card(
                            clipBehavior: Clip.antiAlias,
                            elevation: 0,
                            margin: EdgeInsets.all(0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadiusStyle.roundedBorder20,
                            ),
                            child: Container(
                              height: 135.v,
                              width: 115.h,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadiusStyle.roundedBorder20,
                                image: DecorationImage(
                                  image: AssetImage(
                                    ImageConstant.imgFrame31,
                                  ),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Opacity(
                                    opacity: 0.8,
                                    child: Align(
                                      alignment: Alignment.bottomLeft,
                                      child: Container(
                                        height: 56.v,
                                        width: 70.h,
                                        decoration: BoxDecoration(
                                          color: appTheme.blueGray200A2,
                                          borderRadius: BorderRadius.circular(
                                            35.h,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  CustomImageView(
                                    imagePath: ImageConstant.imgImage13135x115,
                                    height: 135.v,
                                    width: 115.h,
                                    radius: BorderRadius.circular(
                                      20.h,
                                    ),
                                    alignment: Alignment.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 7.v),
                          CustomElevatedButton(
                            height: 37.v,
                            width: 115.h,
                            text: "Continue",
                            buttonTextStyle:
                                CustomTextStyles.labelLargeInterGray10003,
                            alignment: Alignment.center,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        top: 36.v,
                        bottom: 30.v,
                      ),
                      child: Column(
                        children: [
                          Text(
                            "Lucy’s mind",
                            style: CustomTextStyles.titleSmallOnPrimary,
                          ),
                          SizedBox(height: 23.v),
                          SizedBox(
                            width: 98.h,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomSwitch(
                                  margin: EdgeInsets.only(bottom: 5.v),
                                  value: isSelectedSwitch,
                                  onChange: (value) {
                                    isSelectedSwitch = value;
                                  },
                                ),
                                Text(
                                  "65% read",
                                  style: CustomTextStyles.labelMediumMedium,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 3.v),
                          SizedBox(
                            width: 100.h,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(bottom: 1.v),
                                  child: Text(
                                    "home",
                                    style: CustomTextStyles.labelMediumMedium,
                                  ),
                                ),
                                Container(
                                  height: 3.adaptSize,
                                  width: 3.adaptSize,
                                  margin: EdgeInsets.symmetric(vertical: 7.v),
                                  decoration: BoxDecoration(
                                    color: appTheme.blueGray20002,
                                    borderRadius: BorderRadius.circular(
                                      1.h,
                                    ),
                                  ),
                                ),
                                Text(
                                  "2 min ago",
                                  style: CustomTextStyles.labelMediumMedium,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 10.v),
                          _buildLucySMind(
                            context,
                            text: "See on list",
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(left: 24.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 13.h,
                  vertical: 10.v,
                ),
                decoration: AppDecoration.outlinePrimaryContainer2.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder20,
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 7.v),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Card(
                            clipBehavior: Clip.antiAlias,
                            elevation: 0,
                            margin: EdgeInsets.all(0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadiusStyle.roundedBorder20,
                            ),
                            child: Container(
                              height: 135.v,
                              width: 115.h,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadiusStyle.roundedBorder20,
                                image: DecorationImage(
                                  image: AssetImage(
                                    ImageConstant.imgFrame31,
                                  ),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Opacity(
                                    opacity: 0.8,
                                    child: Align(
                                      alignment: Alignment.bottomLeft,
                                      child: Container(
                                        height: 56.v,
                                        width: 70.h,
                                        decoration: BoxDecoration(
                                          color: appTheme.blueGray200A2,
                                          borderRadius: BorderRadius.circular(
                                            35.h,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  CustomImageView(
                                    imagePath: ImageConstant.imgImage13135x115,
                                    height: 135.v,
                                    width: 115.h,
                                    radius: BorderRadius.circular(
                                      20.h,
                                    ),
                                    alignment: Alignment.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 7.v),
                          Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                              height: 37.v,
                              width: 115.h,
                              child: Stack(
                                alignment: Alignment.topLeft,
                                children: [
                                  CustomImageView(
                                    imagePath: ImageConstant.imgFrame49,
                                    height: 37.v,
                                    width: 115.h,
                                    radius: BorderRadius.circular(
                                      9.h,
                                    ),
                                    alignment: Alignment.center,
                                  ),
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                        left: 20.h,
                                        top: 9.v,
                                      ),
                                      child: Text(
                                        "Continue",
                                        style: CustomTextStyles
                                            .labelLargeInterGray10003,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 18.h,
                        top: 35.v,
                        bottom: 30.v,
                      ),
                      child: Column(
                        children: [
                          Text(
                            "Lucy’s mind",
                            style: CustomTextStyles.titleSmallOnPrimary,
                          ),
                          SizedBox(height: 26.v),
                          SizedBox(
                            width: 98.h,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomSwitch(
                                  margin: EdgeInsets.only(bottom: 6.v),
                                  value: isSelectedSwitch1,
                                  onChange: (value) {
                                    isSelectedSwitch1 = value;
                                  },
                                ),
                                Text(
                                  "65% read",
                                  style: CustomTextStyles.labelMediumMedium,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 3.v),
                          SizedBox(
                            width: 100.h,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "home",
                                  style: CustomTextStyles.labelMediumMedium,
                                ),
                                Container(
                                  height: 3.adaptSize,
                                  width: 3.adaptSize,
                                  margin: EdgeInsets.symmetric(vertical: 7.v),
                                  decoration: BoxDecoration(
                                    color: appTheme.blueGray20002,
                                    borderRadius: BorderRadius.circular(
                                      1.h,
                                    ),
                                  ),
                                ),
                                Text(
                                  "2 min ago",
                                  style: CustomTextStyles.labelMediumMedium,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 12.v),
                          _buildLucySMind(
                            context,
                            text: "See on list",
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  /// Common widget
  Widget _buildLucySMind(
    BuildContext context, {
    required String text,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          text,
          style: CustomTextStyles.titleSmallOnPrimaryBold.copyWith(
            color: theme.colorScheme.onPrimary,
          ),
        ),
        CustomImageView(
          imagePath: ImageConstant.imgArrowRightOnprimary,
          height: 12.v,
          width: 6.h,
          margin: EdgeInsets.only(
            left: 10.h,
            top: 5.v,
            bottom: 5.v,
          ),
        ),
      ],
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
