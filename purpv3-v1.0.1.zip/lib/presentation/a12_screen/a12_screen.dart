import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_text_form_field.dart';

class A12Screen extends StatelessWidget {
  A12Screen({Key? key})
      : super(
          key: key,
        );

  TextEditingController typeyouranswerController = TextEditingController();

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 42.h,
            top: 124.v,
            right: 42.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 317.h,
                margin: EdgeInsets.only(left: 11.h),
                child: Text(
                  "What is the highest degree or level of education you have completed?This question is required.",
                  maxLines: 6,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.headlineLarge,
                ),
              ),
              SizedBox(height: 32.v),
              Padding(
                padding: EdgeInsets.only(
                  left: 10.h,
                  right: 41.h,
                ),
                child: CustomTextFormField(
                  controller: typeyouranswerController,
                  hintText: "Type your answer",
                  hintStyle: CustomTextStyles.titleLargeBluegray20002,
                  textInputAction: TextInputAction.done,
                  borderDecoration: TextFormFieldStyleHelper.underLinePrimary,
                  filled: false,
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
