import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';

class A13Screen extends StatelessWidget {
  A13Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 36.h,
            vertical: 49.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 28.v),
              Container(
                width: 324.h,
                margin: EdgeInsets.only(left: 16.h),
                child: Text(
                  "Please select which best describes your occupational status?",
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.headlineLarge,
                ),
              ),
              SizedBox(height: 12.v),
              _buildPleaseSelectWhich(context),
              SizedBox(height: 19.v),
              _buildLessThan100000INR(context),
              SizedBox(height: 19.v),
              _buildTf(context),
              SizedBox(height: 23.v),
              _buildTf1(context),
              SizedBox(height: 19.v),
              _buildTf2(context),
              SizedBox(height: 23.v),
              _buildTf3(context),
              SizedBox(height: 12.v),
              _buildTf4(context),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildPleaseSelectWhich(BuildContext context) {
    return CustomOutlinedButton(
      height: 51.v,
      text: "less than 100000 INR",
      margin: EdgeInsets.only(
        left: 18.h,
        right: 33.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildLessThan100000INR(BuildContext context) {
    return CustomOutlinedButton(
      height: 51.v,
      text: "100001 - 300000",
      margin: EdgeInsets.only(
        left: 18.h,
        right: 33.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildTf(BuildContext context) {
    return CustomOutlinedButton(
      height: 51.v,
      text: "300001 - 500000",
      margin: EdgeInsets.only(
        left: 18.h,
        right: 33.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildTf1(BuildContext context) {
    return CustomOutlinedButton(
      height: 51.v,
      text: "500001 - 1000000",
      margin: EdgeInsets.only(
        left: 18.h,
        right: 33.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildTf2(BuildContext context) {
    return CustomOutlinedButton(
      height: 51.v,
      text: "1000001 - 2000000",
      margin: EdgeInsets.only(
        left: 18.h,
        right: 33.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildTf3(BuildContext context) {
    return CustomOutlinedButton(
      height: 51.v,
      text: "2000001 - 4000000",
      margin: EdgeInsets.only(
        left: 18.h,
        right: 33.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildTf4(BuildContext context) {
    return CustomOutlinedButton(
      height: 51.v,
      text: "pore than 4000000",
      margin: EdgeInsets.only(
        left: 17.h,
        right: 33.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
