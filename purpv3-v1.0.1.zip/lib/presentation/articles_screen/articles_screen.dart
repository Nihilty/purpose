import '../articles_screen/widgets/cseanalyticsresults_item_widget.dart';import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/presentation/homeone_page/homeone_page.dart';import 'package:purpv3/presentation/homepage_page/homepage_page.dart';import 'package:purpv3/widgets/custom_bottom_bar.dart';
// ignore_for_file: must_be_immutable
class ArticlesScreen extends StatelessWidget {ArticlesScreen({Key? key}) : super(key: key);

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(backgroundColor: theme.colorScheme.onError, body: SizedBox(height: 815.v, width: double.maxFinite, child: Stack(alignment: Alignment.topRight, children: [_buildArrowLeft(context), CustomImageView(imagePath: ImageConstant.imgEllipse140x182, height: 140.v, width: 182.h, alignment: Alignment.topRight), CustomImageView(imagePath: ImageConstant.imgEllipse147x71, height: 147.v, width: 71.h, alignment: Alignment.topRight, margin: EdgeInsets.only(top: 78.v)), Align(alignment: Alignment.topLeft, child: Container(height: 50.v, width: 331.h, margin: EdgeInsets.only(left: 22.h, top: 156.v), decoration: BoxDecoration(color: appTheme.whiteA700, borderRadius: BorderRadius.circular(25.h), boxShadow: [BoxShadow(color: appTheme.gray40026, spreadRadius: 2.h, blurRadius: 2.h, offset: Offset(3, 5))]))), Align(alignment: Alignment.topRight, child: Padding(padding: EdgeInsets.only(top: 117.v), child: Text("Articles", style: CustomTextStyles.poppinsWhiteA700))), Align(alignment: Alignment.topLeft, child: Padding(padding: EdgeInsets.only(left: 47.h, top: 172.v), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [CustomImageView(imagePath: ImageConstant.imgRewind, height: 14.v, width: 13.h, margin: EdgeInsets.only(top: 1.v, bottom: 5.v)), Padding(padding: EdgeInsets.only(left: 11.h), child: Text("Search For Articles", style: CustomTextStyles.bodyMediumBluegray100))]))), CustomImageView(imagePath: ImageConstant.imgGroup23, height: 22.v, width: 4.h, alignment: Alignment.topRight, margin: EdgeInsets.only(top: 62.v, right: 29.h)), _buildCSEAnalyticsResults(context)])), bottomNavigationBar: _buildBottomBar(context))); } 
/// Section Widget
Widget _buildArrowLeft(BuildContext context) { return Align(alignment: Alignment.topCenter, child: Container(padding: EdgeInsets.symmetric(horizontal: 23.h, vertical: 61.v), decoration: AppDecoration.fillPrimary, child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [CustomImageView(imagePath: ImageConstant.imgArrowLeftWhiteA70024x24, height: 24.adaptSize, width: 24.adaptSize, onTap: () {onTapImgArrowLeft(context);}), SizedBox(height: 16.v), Text("Articles", style: CustomTextStyles.headlineLargeWhiteA700), SizedBox(height: 8.v)]))); } 
/// Section Widget
Widget _buildCSEAnalyticsResults(BuildContext context) { return Align(alignment: Alignment.bottomCenter, child: Padding(padding: EdgeInsets.only(left: 41.h, top: 236.v, right: 41.h), child: ListView.separated(physics: NeverScrollableScrollPhysics(), shrinkWrap: true, separatorBuilder: (context, index) {return SizedBox(height: 25.v);}, itemCount: 2, itemBuilder: (context, index) {return CseanalyticsresultsItemWidget(onTapCSEAnalyticsResults: () {onTapCSEAnalyticsResults(context);});}))); } 
/// Section Widget
Widget _buildBottomBar(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.Home: return AppRoutes.homeonePage; case BottomBarEnum.Career: return AppRoutes.homepagePage; case BottomBarEnum.Chat: return "/"; case BottomBarEnum.Me: return "/"; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.homeonePage: return HomeonePage(); case AppRoutes.homepagePage: return HomepagePage(); default: return DefaultWidget();} } 
/// Navigates to the detailArticlesScreen when the action is triggered.
onTapCSEAnalyticsResults(BuildContext context) { Navigator.pushNamed(context, AppRoutes.detailArticlesScreen); } 

/// Navigates back to the previous screen.
onTapImgArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
