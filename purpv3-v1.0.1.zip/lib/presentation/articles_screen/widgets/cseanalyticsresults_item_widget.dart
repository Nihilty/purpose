import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore: must_be_immutable
class CseanalyticsresultsItemWidget extends StatelessWidget {
  CseanalyticsresultsItemWidget({
    Key? key,
    this.onTapCSEAnalyticsResults,
  }) : super(
          key: key,
        );

  VoidCallback? onTapCSEAnalyticsResults;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: GestureDetector(
        onTap: () {
          onTapCSEAnalyticsResults!.call();
        },
        child: Container(
          height: 259.v,
          width: 331.h,
          decoration: AppDecoration.outlinePrimary3,
          child: Stack(
            alignment: Alignment.topCenter,
            children: [
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  padding: EdgeInsets.all(15.h),
                  decoration: AppDecoration.outlinePrimary4.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder10,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(height: 6.v),
                      Container(
                        width: 292.h,
                        margin: EdgeInsets.only(right: 8.h),
                        child: Text(
                          "CSE analytics: Results released for the Year 2023",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style:
                              CustomTextStyles.titleSmallBluegray800.copyWith(
                            height: 1.52,
                          ),
                        ),
                      ),
                      SizedBox(height: 6.v),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgEllipse3128x28,
                            height: 28.adaptSize,
                            width: 28.adaptSize,
                            radius: BorderRadius.circular(
                              14.h,
                            ),
                            margin: EdgeInsets.only(bottom: 2.v),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 9.h),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Big girl",
                                  style:
                                      CustomTextStyles.labelMediumBluegray800,
                                ),
                                Text(
                                  "2019 . 01 . 01",
                                  style:
                                      CustomTextStyles.labelSmallErrorContainer,
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          CustomImageView(
                            imagePath: ImageConstant.imgShare2,
                            height: 18.adaptSize,
                            width: 18.adaptSize,
                            margin: EdgeInsets.only(
                              top: 8.v,
                              bottom: 4.v,
                            ),
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.imgBookmark,
                            height: 19.v,
                            width: 38.h,
                            margin: EdgeInsets.only(
                              left: 6.h,
                              top: 8.v,
                              bottom: 3.v,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              CustomImageView(
                imagePath: ImageConstant.imgRectangle221,
                height: 145.v,
                width: 331.h,
                radius: BorderRadius.vertical(
                  top: Radius.circular(13.h),
                ),
                alignment: Alignment.topCenter,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
