import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore: must_be_immutable
class CareerdevelopmentsectionItemWidget extends StatelessWidget {
  const CareerdevelopmentsectionItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 299.h,
      child: Align(
        alignment: Alignment.centerRight,
        child: Container(
          height: 160.v,
          width: 299.h,
          margin: EdgeInsets.only(top: 1.v),
          child: Stack(
            alignment: Alignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgRectangle44,
                height: 160.v,
                width: 299.h,
                radius: BorderRadius.circular(
                  3.h,
                ),
                alignment: Alignment.center,
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 29.h,
                    vertical: 8.v,
                  ),
                  decoration: AppDecoration.fillGray80038.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder3,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SizedBox(height: 87.v),
                      SizedBox(
                        width: 114.h,
                        child: Text(
                          "CAREER DEVELOPMENT",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: CustomTextStyles.titleSmallInterPrimary,
                        ),
                      ),
                      SizedBox(height: 6.v),
                      Text(
                        "BY J.OPPENHEIMER",
                        style: CustomTextStyles.labelMediumInterWhiteA700,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
