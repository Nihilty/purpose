import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore: must_be_immutable
class Userprofilesection1ItemWidget extends StatelessWidget {
  const Userprofilesection1ItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 126.h,
      child: Align(
        alignment: Alignment.centerRight,
        child: SizedBox(
          height: 144.v,
          width: 126.h,
          child: Stack(
            alignment: Alignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgRectangle25,
                height: 144.v,
                width: 126.h,
                radius: BorderRadius.circular(
                  3.h,
                ),
                alignment: Alignment.center,
              ),
              Align(
                alignment: Alignment.center,
                child: SizedBox(
                  height: 144.v,
                  width: 126.h,
                  child: Stack(
                    alignment: Alignment.bottomLeft,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle27,
                        height: 144.v,
                        width: 126.h,
                        radius: BorderRadius.circular(
                          3.h,
                        ),
                        alignment: Alignment.center,
                      ),
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Container(
                          width: 50.h,
                          margin: EdgeInsets.only(bottom: 15.v),
                          padding: EdgeInsets.symmetric(
                            horizontal: 9.h,
                            vertical: 1.v,
                          ),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                            borderRadius: BorderRadiusStyle.customBorderLR3,
                          ),
                          child: Text(
                            "#Mini",
                            style: CustomTextStyles.labelMediumBluegray900cc,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
