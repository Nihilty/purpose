import '../homepage_page/widgets/careerdevelopmentsection_item_widget.dart';
import '../homepage_page/widgets/progresssection_item_widget.dart';
import '../homepage_page/widgets/userprofilesection1_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/app_bar/appbar_subtitle_two.dart';
import 'package:purpv3/widgets/app_bar/appbar_trailing_image.dart';
import 'package:purpv3/widgets/app_bar/custom_app_bar.dart';
import 'package:purpv3/widgets/custom_search_view.dart';

// ignore_for_file: must_be_immutable
class HomepagePage extends StatelessWidget {
  HomepagePage({Key? key})
      : super(
          key: key,
        );

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.onError,
        resizeToAvoidBottomInset: false,
        body: Container(
          width: 375.h,
          decoration: AppDecoration.fillOnError,
          child: Column(
            children: [
              _buildHelloCharlieSection(context),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 29.v),
                  _buildProgressSection(context),
                  SizedBox(height: 28.v),
                  Padding(
                    padding: EdgeInsets.only(left: 27.h),
                    child: Text(
                      "RESOURCES",
                      style: CustomTextStyles.titleSmallInterPrimary,
                    ),
                  ),
                  SizedBox(height: 12.v),
                  _buildCareerDevelopmentSection(context),
                  SizedBox(height: 34.v),
                  Padding(
                    padding: EdgeInsets.only(left: 27.h),
                    child: Text(
                      "GAMES",
                      style: CustomTextStyles.titleSmallInterPrimary,
                    ),
                  ),
                  SizedBox(height: 7.v),
                  _buildUserProfileSection(context),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildHelloCharlieSection(BuildContext context) {
    return SizedBox(
      height: 165.v,
      width: 375.h,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: 24.h,
                vertical: 25.v,
              ),
              decoration: AppDecoration.gradientOnSecondaryContainerToGray,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 57.v),
                  Text(
                    "Hello Charlie,",
                    style: CustomTextStyles.titleLargeInter21,
                  ),
                ],
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgEllipse81x168,
            height: 81.v,
            width: 168.h,
            alignment: Alignment.topRight,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgEllipse124x75,
            height: 124.v,
            width: 75.h,
            alignment: Alignment.bottomRight,
            margin: EdgeInsets.only(bottom: 12.v),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Text(
              "Home",
              style: CustomTextStyles.poppinsWhiteA700Black,
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(bottom: 5.v),
              child: CustomSearchView(
                width: 329.h,
                controller: searchController,
                hintText: "Search anything",
                alignment: Alignment.bottomCenter,
                borderDecoration: SearchViewStyleHelper.outlinePrimary,
              ),
            ),
          ),
          CustomAppBar(
            height: 80.v,
            title: AppbarSubtitleTwo(
              text: "Are you ready to start your journey?",
              margin: EdgeInsets.only(
                left: 24.h,
                top: 42.v,
              ),
            ),
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgFace1,
                margin: EdgeInsets.only(
                  left: 35.h,
                  right: 35.h,
                  bottom: 1.v,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildProgressSection(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: SizedBox(
        height: 76.v,
        child: ListView.separated(
          padding: EdgeInsets.only(
            left: 14.h,
            right: 23.h,
          ),
          scrollDirection: Axis.horizontal,
          separatorBuilder: (
            context,
            index,
          ) {
            return SizedBox(
              width: 22.h,
            );
          },
          itemCount: 3,
          itemBuilder: (context, index) {
            return ProgresssectionItemWidget();
          },
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildCareerDevelopmentSection(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: SizedBox(
        height: 161.v,
        child: ListView.separated(
          padding: EdgeInsets.only(left: 23.h),
          scrollDirection: Axis.horizontal,
          separatorBuilder: (
            context,
            index,
          ) {
            return SizedBox(
              width: 14.h,
            );
          },
          itemCount: 2,
          itemBuilder: (context, index) {
            return CareerdevelopmentsectionItemWidget();
          },
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileSection(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: SizedBox(
        height: 144.v,
        child: ListView.separated(
          padding: EdgeInsets.only(left: 23.h),
          scrollDirection: Axis.horizontal,
          separatorBuilder: (
            context,
            index,
          ) {
            return SizedBox(
              width: 17.h,
            );
          },
          itemCount: 3,
          itemBuilder: (context, index) {
            return Userprofilesection1ItemWidget();
          },
        ),
      ),
    );
  }
}
