import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';

class A9Screen extends StatelessWidget {
  A9Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 60.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 280.h,
                margin: EdgeInsets.only(right: 13.h),
                child: Text(
                  "How many other people do you share your home with?",
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.headlineLarge,
                ),
              ),
              SizedBox(height: 38.v),
              Container(
                width: 159.h,
                margin: EdgeInsets.only(left: 2.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 7.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "0",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                width: 159.h,
                margin: EdgeInsets.only(left: 2.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 7.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "1",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 9.v),
              Container(
                width: 159.h,
                margin: EdgeInsets.only(left: 2.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 6.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "2",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                width: 159.h,
                margin: EdgeInsets.only(left: 2.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 6.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "3",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                width: 159.h,
                margin: EdgeInsets.only(left: 2.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 6.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "4",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                width: 159.h,
                margin: EdgeInsets.only(left: 2.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 7.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "5",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                width: 159.h,
                margin: EdgeInsets.only(left: 2.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 30.h,
                  vertical: 7.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "6+",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 9.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBarSection(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBarSection(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
