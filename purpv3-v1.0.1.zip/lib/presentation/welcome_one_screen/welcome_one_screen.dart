import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/custom_elevated_button.dart';

class WelcomeOneScreen extends StatelessWidget {
  const WelcomeOneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 38.h),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 48.v),
              SizedBox(
                height: 183.adaptSize,
                width: 183.adaptSize,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: 183.adaptSize,
                        width: 183.adaptSize,
                        decoration: BoxDecoration(
                          color: appTheme.gray10003,
                          borderRadius: BorderRadius.circular(
                            91.h,
                          ),
                        ),
                      ),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgEllipse8,
                      height: 183.adaptSize,
                      width: 183.adaptSize,
                      radius: BorderRadius.circular(
                        91.h,
                      ),
                      alignment: Alignment.center,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 27.v),
              Text(
                "Welcome",
                style: CustomTextStyles.titleLargePrimarySemiBold,
              ),
              SizedBox(height: 1.v),
              Text(
                "Charlie!!!",
                style: CustomTextStyles.titleLargePrimarySemiBold,
              ),
              SizedBox(height: 21.v),
              CustomElevatedButton(
                text: "Continue",
              ),
            ],
          ),
        ),
      ),
    );
  }
}
