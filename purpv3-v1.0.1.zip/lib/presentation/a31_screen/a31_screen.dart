import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';

class A31Screen extends StatelessWidget {
  A31Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 52.h,
            top: 88.v,
            right: 52.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 287.h,
                margin: EdgeInsets.only(right: 20.h),
                child: Text(
                  "How regularly do you engage in physical exercise (30 minutes or more)?",
                  maxLines: 5,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.headlineLarge,
                ),
              ),
              SizedBox(height: 59.v),
              _buildDuration(context),
              SizedBox(height: 34.v),
              _buildFewDaysAWeek(context),
              SizedBox(height: 34.v),
              _buildOnceAWeek(context),
              SizedBox(height: 33.v),
              _buildNever(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildDuration(BuildContext context) {
    return CustomOutlinedButton(
      text: "everyday",
      margin: EdgeInsets.only(
        left: 5.h,
        right: 83.h,
      ),
    );
  }

  /// Section Widget
  Widget _buildFewDaysAWeek(BuildContext context) {
    return CustomOutlinedButton(
      text: "few days a week",
      margin: EdgeInsets.only(
        left: 5.h,
        right: 36.h,
      ),
    );
  }

  /// Section Widget
  Widget _buildOnceAWeek(BuildContext context) {
    return CustomOutlinedButton(
      text: "once a week",
      margin: EdgeInsets.only(
        left: 5.h,
        right: 83.h,
      ),
    );
  }

  /// Section Widget
  Widget _buildNever(BuildContext context) {
    return CustomOutlinedButton(
      width: 156.h,
      text: "never",
      margin: EdgeInsets.only(left: 5.h),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
