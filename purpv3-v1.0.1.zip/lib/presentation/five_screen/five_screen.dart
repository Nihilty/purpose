import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/app_bar/appbar_leading_image.dart';import 'package:purpv3/widgets/app_bar/appbar_trailing_image.dart';import 'package:purpv3/widgets/app_bar/custom_app_bar.dart';import 'package:purpv3/widgets/custom_outlined_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class FiveScreen extends StatelessWidget {FiveScreen({Key? key}) : super(key: key);

TextEditingController mapEditTextController = TextEditingController();

TextEditingController futureScopeValueEditTextController = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(backgroundColor: appTheme.gray10001, resizeToAvoidBottomInset: false, appBar: _buildAppBar(context), body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 45.h, vertical: 10.v), child: Column(children: [Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.only(left: 8.h), child: Text("What", style: theme.textTheme.bodyLarge))), SizedBox(height: 1.v), Opacity(opacity: 0.5, child: Container(width: 299.h, margin: EdgeInsets.only(left: 8.h, right: 16.h), child: Text("A web designer creates the layout and design of a website. In simple terms, a website designer makes a site look good.", maxLines: 4, overflow: TextOverflow.ellipsis, style: CustomTextStyles.bodyMediumPrimary.copyWith(height: 1.39)))), SizedBox(height: 22.v), SizedBox(height: 275.v, width: 279.h, child: Stack(alignment: Alignment.center, children: [CustomImageView(imagePath: ImageConstant.imgRectangle299, height: 275.v, width: 279.h, radius: BorderRadius.circular(23.h), alignment: Alignment.center), CustomImageView(imagePath: ImageConstant.imgUser, height: 89.v, width: 85.h, radius: BorderRadius.circular(10.h), alignment: Alignment.center)])), SizedBox(height: 29.v), _buildMoreVideosButton(context), SizedBox(height: 14.v), _buildMapEditText(context), SizedBox(height: 29.v), _buildFutureScopeValueEditText(context), SizedBox(height: 5.v)])), bottomNavigationBar: _buildSeeHowMuchYouCanMakeButton(context))); } 
/// Section Widget
PreferredSizeWidget _buildAppBar(BuildContext context) { return CustomAppBar(leadingWidth: 65.h, leading: AppbarLeadingImage(imagePath: ImageConstant.imgChevronLeft, margin: EdgeInsets.only(left: 41.h, top: 16.v, bottom: 16.v), onTap: () {onTapArrowLeft(context);}), actions: [AppbarTrailingImage(imagePath: ImageConstant.imgHeart, margin: EdgeInsets.fromLTRB(54.h, 16.v, 54.h, 20.v))]); } 
/// Section Widget
Widget _buildMoreVideosButton(BuildContext context) { return CustomOutlinedButton(width: 150.h, text: "More Videos", buttonStyle: CustomButtonStyles.outlinePrimary1, buttonTextStyle: theme.textTheme.bodyLarge!); } 
/// Section Widget
Widget _buildMapEditText(BuildContext context) { return CustomTextFormField(controller: mapEditTextController, hintText: "What you do as a career?", suffix: Container(margin: EdgeInsets.fromLTRB(28.h, 21.v, 27.h, 21.v), child: CustomImageView(imagePath: ImageConstant.imgMap, height: 18.adaptSize, width: 18.adaptSize)), suffixConstraints: BoxConstraints(maxHeight: 67.v)); } 
/// Section Widget
Widget _buildFutureScopeValueEditText(BuildContext context) { return CustomTextFormField(controller: futureScopeValueEditTextController, hintText: "Future Scope", textInputAction: TextInputAction.done, suffix: Container(margin: EdgeInsets.fromLTRB(30.h, 24.v, 27.h, 24.v), child: CustomImageView(imagePath: ImageConstant.imgMap, height: 18.adaptSize, width: 18.adaptSize)), suffixConstraints: BoxConstraints(maxHeight: 67.v)); } 
/// Section Widget
Widget _buildSeeHowMuchYouCanMakeButton(BuildContext context) { return CustomOutlinedButton(height: 67.v, text: "See how much you can make", margin: EdgeInsets.only(left: 44.h, right: 51.h, bottom: 58.v), buttonStyle: CustomButtonStyles.outlineTealA, buttonTextStyle: theme.textTheme.bodyLarge!); } 

/// Navigates back to the previous screen.
onTapArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
