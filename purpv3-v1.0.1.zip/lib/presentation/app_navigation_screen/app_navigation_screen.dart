import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFFFFFF),
        body: SizedBox(
          width: 375.h,
          child: Column(
            children: [
              _buildAppNavigation(context),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0XFFFFFFFF),
                    ),
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          context,
                          screenTitle: "a2",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a2Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "assessment",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.assessmentScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a3",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a3Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a4",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a4Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a5",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a5Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a6",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a6Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a7",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a7Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a8",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a8Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a9",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a9Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a10",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a10Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a11",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a11Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a12",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a12Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a13",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a13Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a14",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a14Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a15",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a15Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a16",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a16Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a17",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a17Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a18",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a18Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a19 ",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a19Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a20",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a20Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a21",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a21Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a22",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a22Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a23",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a23Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a24",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a24Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a25",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a25Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a26",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a26Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a27",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a27Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a28",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a28Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a29",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a29Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a30",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a30Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a31",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a31Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a32",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a32Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a33",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a33Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a34",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a34Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a35",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a35Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a36",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a36Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a37",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a37Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a38",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a38Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "a39",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.a39Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "me1 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.me1OneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "me2",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.me2Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "me3",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.me3Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "pageOne",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.pageoneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "homeOne One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.homeoneOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Startpage",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.startpageScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "homeOne - Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.homeoneContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "SPLASH",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.splashScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "ONBOARDING One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.onboardingOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "ONBOARDING Two",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.onboardingTwoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "ONBOARDING Three",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.onboardingThreeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Profile - Tab Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.profileTabContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Profile Two - Tab Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.profileTwoTabContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Profile One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.profileOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.oneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.twoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "3 ",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k61Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Four",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.fourScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "homeOne Two",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.homeoneTwoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "CHAT",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.chatScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "CHAT LIST",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.chatListScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Articles",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.articlesScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Detail Articles",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.detailArticlesScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Author ",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.authorScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Five",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.fiveScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Eight",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.eightScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "pageOne One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.pageoneOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Startpage One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.startpageOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "SIGN IN",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.signInScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "FORGOT PASSWORD",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.forgotPasswordScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "VERIFICATION",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.verificationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "PASSWORD RESET",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.passwordResetScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "WELCOME",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.welcomeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "SIGN UP",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.signUpScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "VERIFICATION One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.verificationOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "PERSONAL INFORMATION",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.personalInformationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "username",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.usernameScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "WELCOME One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.welcomeOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Six",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.sixScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Nine",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.nineScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Seven",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.sevenScreen),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0XFFFFFFFF),
      ),
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF000000),
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF888888),
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: Color(0XFF000000),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle(
    BuildContext context, {
    required String screenTitle,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle!.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Color(0XFFFFFFFF),
        ),
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  screenTitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: Color(0XFF888888),
            ),
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(
    BuildContext context,
    String routeName,
  ) {
    Navigator.pushNamed(context, routeName);
  }
}
