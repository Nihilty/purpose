import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/custom_elevated_button.dart';

class StartpageScreen extends StatelessWidget {
  const StartpageScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 46.h,
            vertical: 53.v,
          ),
          child: Column(
            children: [
              SizedBox(height: 23.v),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgSettings,
                    height: 79.v,
                    width: 59.h,
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 26.h,
                      top: 14.v,
                      bottom: 12.v,
                    ),
                    child: Text(
                      "PURPOSE",
                      style: theme.textTheme.displaySmall,
                    ),
                  ),
                ],
              ),
              Spacer(),
              CustomImageView(
                imagePath: ImageConstant.imgImage12,
                height: 258.v,
                width: 235.h,
              ),
              SizedBox(height: 66.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 5.h),
                  child: Text(
                    "Hi, Nice to Meet You!!",
                    style: CustomTextStyles.titleLargePrimarySemiBold,
                  ),
                ),
              ),
              SizedBox(height: 15.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 289.h,
                  margin: EdgeInsets.only(
                    left: 5.h,
                    right: 27.h,
                  ),
                  child: Text(
                    "Register in our application or log in if your account already exists.",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: CustomTextStyles.bodyMediumPrimary14,
                  ),
                ),
              ),
              SizedBox(height: 38.v),
              CustomElevatedButton(
                text: "Log In",
              ),
              SizedBox(height: 25.v),
              CustomElevatedButton(
                text: "Register",
              ),
            ],
          ),
        ),
      ),
    );
  }
}
