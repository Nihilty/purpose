import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class PasswordResetScreen extends StatelessWidget {PasswordResetScreen({Key? key}) : super(key: key);

TextEditingController newpasswordController = TextEditingController();

TextEditingController newpasswordController1 = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 27.h, vertical: 16.v), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(height: 47.v), Align(alignment: Alignment.center, child: Text("PURPOSE", style: CustomTextStyles.titleLargePrimaryMedium)), SizedBox(height: 37.v), CustomImageView(imagePath: ImageConstant.imgArrowLeft, height: 20.v, width: 11.h, margin: EdgeInsets.only(left: 2.h), onTap: () {onTapImgArrowLeft(context);}), SizedBox(height: 38.v), Text("Pick a new Password", style: CustomTextStyles.titleLargePrimaryBlack), SizedBox(height: 3.v), Opacity(opacity: 0.7, child: Text("Help secure your account", style: CustomTextStyles.titleMediumPrimaryMedium16_3)), SizedBox(height: 18.v), Opacity(opacity: 0.7, child: Text("New Password", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), CustomTextFormField(controller: newpasswordController, obscureText: true), SizedBox(height: 11.v), Opacity(opacity: 0.7, child: Text("Confirm new Password", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), CustomTextFormField(controller: newpasswordController1, textInputAction: TextInputAction.done, obscureText: true, borderDecoration: TextFormFieldStyleHelper.fillGray), Spacer(), CustomElevatedButton(text: "Next", margin: EdgeInsets.only(left: 19.h, right: 20.h), onPressed: () {onTapNext(context);}, alignment: Alignment.center), SizedBox(height: 38.v), Container(width: 185.h, margin: EdgeInsets.only(left: 74.h), child: RichText(text: TextSpan(children: [TextSpan(text: "Already have an account? ", style: CustomTextStyles.titleSmallff000000), TextSpan(text: "Sign Up", style: CustomTextStyles.titleSmallff000000Bold.copyWith(decoration: TextDecoration.underline))]), textAlign: TextAlign.left))])))); } 

/// Navigates back to the previous screen.
onTapImgArrowLeft(BuildContext context) { Navigator.pop(context); } 
/// Navigates to the welcomeScreen when the action is triggered.
onTapNext(BuildContext context) { Navigator.pushNamed(context, AppRoutes.welcomeScreen); } 
 }
