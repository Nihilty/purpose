import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/presentation/homeone_page/homeone_page.dart';import 'package:purpv3/presentation/homepage_page/homepage_page.dart';import 'package:purpv3/widgets/custom_bottom_bar.dart';import 'package:purpv3/widgets/custom_outlined_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class A21Screen extends StatelessWidget {A21Screen({Key? key}) : super(key: key);

TextEditingController typeyouranswerController = TextEditingController();

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 34.h), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [SizedBox(height: 30.v), Container(width: 334.h, margin: EdgeInsets.only(left: 5.h, right: 6.h), child: RichText(text: TextSpan(children: [TextSpan(text: "Assess your: Self Control & Impulsivity\n\"Your ability to demonstrate appropriate levels of self control in your thoughts and actions and to regulate your impulsivity\"\n\n", style: CustomTextStyles.titleLargeff000000), TextSpan(text: "Look at the scale below. Choose a number of stars between 1 and 9", style: CustomTextStyles.bodyLargeff000000)]), textAlign: TextAlign.left)), SizedBox(height: 95.v), CustomImageView(imagePath: ImageConstant.imgRectangle341, height: 87.v, width: 339.h), SizedBox(height: 40.v), Padding(padding: EdgeInsets.only(left: 5.h, right: 17.h), child: CustomTextFormField(controller: typeyouranswerController, hintText: "Type your answer", hintStyle: CustomTextStyles.titleLargeBluegray20002, textInputAction: TextInputAction.done, borderDecoration: TextFormFieldStyleHelper.underLinePrimary, filled: false)), SizedBox(height: 70.v), CustomOutlinedButton(height: 59.v, width: 160.h, text: "continue", margin: EdgeInsets.only(left: 85.h), buttonStyle: CustomButtonStyles.outlinePrimary, buttonTextStyle: CustomTextStyles.titleLargeInter, onPressed: () {onTapContinue(context);})])), bottomNavigationBar: Padding(padding: EdgeInsets.only(left: 17.h, right: 22.h), child: _buildBottomBarSection(context)))); } 
/// Section Widget
Widget _buildBottomBarSection(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.Home: return AppRoutes.homeonePage; case BottomBarEnum.Career: return AppRoutes.homepagePage; case BottomBarEnum.Chat: return "/"; case BottomBarEnum.Me: return "/"; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.homeonePage: return HomeonePage(); case AppRoutes.homepagePage: return HomepagePage(); default: return DefaultWidget();} } 
/// Navigates to the a22Screen when the action is triggered.
onTapContinue(BuildContext context) { Navigator.pushNamed(context, AppRoutes.a22Screen); } 
 }
