import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';

class A8Screen extends StatelessWidget {
  A8Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 58.h),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 26.v),
              Container(
                width: 270.h,
                margin: EdgeInsets.only(
                  left: 11.h,
                  right: 16.h,
                ),
                child: Text(
                  "Which of the following best describes the place where you now live",
                  maxLines: 5,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.headlineLarge,
                ),
              ),
              SizedBox(height: 19.v),
              _buildLargeCityButton(context),
              SizedBox(height: 40.v),
              Container(
                width: 287.h,
                margin: EdgeInsets.only(left: 11.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 6.h,
                  vertical: 9.v,
                ),
                decoration: AppDecoration.outlinePrimary.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder7,
                ),
                child: Text(
                  "A suburb near a large city",
                  style: CustomTextStyles.titleLargeBold,
                ),
              ),
              SizedBox(height: 37.v),
              _buildSmallCityButton(context),
              SizedBox(height: 35.v),
              _buildRemoteCommunityButton(context),
              SizedBox(height: 36.v),
              _buildPreferNotToSayButton(context),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildLargeCityButton(BuildContext context) {
    return CustomOutlinedButton(
      text: "A large city",
      margin: EdgeInsets.only(
        left: 14.h,
        right: 70.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
      alignment: Alignment.centerLeft,
    );
  }

  /// Section Widget
  Widget _buildSmallCityButton(BuildContext context) {
    return CustomOutlinedButton(
      text: "A small city or town",
      margin: EdgeInsets.only(
        left: 11.h,
        right: 47.h,
      ),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
      alignment: Alignment.centerLeft,
    );
  }

  /// Section Widget
  Widget _buildRemoteCommunityButton(BuildContext context) {
    return CustomOutlinedButton(
      height: 52.v,
      text: "a remote community",
      margin: EdgeInsets.only(left: 11.h),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildPreferNotToSayButton(BuildContext context) {
    return CustomOutlinedButton(
      height: 52.v,
      text: "prefer not to say",
      margin: EdgeInsets.only(left: 11.h),
      buttonTextStyle: CustomTextStyles.titleLargeBold,
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
