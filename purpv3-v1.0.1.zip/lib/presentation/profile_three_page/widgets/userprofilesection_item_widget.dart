import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore: must_be_immutable
class UserprofilesectionItemWidget extends StatelessWidget {
  const UserprofilesectionItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 267.v,
      width: 331.h,
      decoration: AppDecoration.outlinePrimary3,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.all(15.h),
              decoration: AppDecoration.outlinePrimary4.copyWith(
                borderRadius: BorderRadiusStyle.customBorderTL10,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 6.v),
                  SizedBox(
                    width: 300.h,
                    child: Text(
                      "Dravida Austin,Accomplishes her Life’s wish at 22",
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.titleSmallBluegray800.copyWith(
                        height: 1.52,
                      ),
                    ),
                  ),
                  SizedBox(height: 4.v),
                  Padding(
                    padding: EdgeInsets.only(left: 6.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgSettingsPrimary,
                          height: 33.v,
                          width: 35.h,
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 18.h,
                            top: 2.v,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Charlie king",
                                style: CustomTextStyles.labelMediumGray800,
                              ),
                              Text(
                                "2019 . 01 . 01",
                                style:
                                    CustomTextStyles.labelSmallErrorContainer,
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        CustomImageView(
                          imagePath: ImageConstant.imgLockOnprimarycontainer,
                          height: 19.v,
                          width: 38.h,
                          margin: EdgeInsets.only(
                            top: 10.v,
                            bottom: 4.v,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgRectangle22145x331,
            height: 145.v,
            width: 331.h,
            radius: BorderRadius.vertical(
              top: Radius.circular(13.h),
            ),
            alignment: Alignment.topCenter,
            margin: EdgeInsets.only(top: 8.v),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgImage13,
            height: 160.v,
            width: 331.h,
            radius: BorderRadius.vertical(
              top: Radius.circular(18.h),
            ),
            alignment: Alignment.topCenter,
          ),
        ],
      ),
    );
  }
}
