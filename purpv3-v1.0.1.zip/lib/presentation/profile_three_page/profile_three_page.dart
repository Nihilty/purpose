import '../profile_three_page/widgets/userprofilesection_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore_for_file: must_be_immutable
class ProfileThreePage extends StatefulWidget {
  const ProfileThreePage({Key? key})
      : super(
          key: key,
        );

  @override
  ProfileThreePageState createState() => ProfileThreePageState();
}

class ProfileThreePageState extends State<ProfileThreePage>
    with AutomaticKeepAliveClientMixin<ProfileThreePage> {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.onError,
        body: Container(
          width: double.maxFinite,
          margin: EdgeInsets.only(top: 47.v),
          decoration: AppDecoration.outlineWhiteA700,
          child: Column(
            children: [
              SizedBox(height: 24.v),
              _buildUserProfileSection(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileSection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 41.h),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            height: 25.v,
          );
        },
        itemCount: 2,
        itemBuilder: (context, index) {
          return UserprofilesectionItemWidget();
        },
      ),
    );
  }
}
