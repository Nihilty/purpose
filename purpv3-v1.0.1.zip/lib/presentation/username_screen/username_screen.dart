import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class UsernameScreen extends StatelessWidget {UsernameScreen({Key? key}) : super(key: key);

TextEditingController usernameEditTextController = TextEditingController();

TextEditingController passwordEditTextController = TextEditingController();

TextEditingController confirmPasswordEditTextController = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 19.h, vertical: 8.v), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(height: 47.v), Align(alignment: Alignment.center, child: Text("PURPOSE", style: CustomTextStyles.titleLargePrimaryMedium)), SizedBox(height: 34.v), CustomImageView(imagePath: ImageConstant.imgArrowLeft, height: 20.v, width: 11.h, margin: EdgeInsets.only(left: 2.h), onTap: () {onTapImgArrowLeft(context);}), SizedBox(height: 35.v), Text("Select a Username", style: CustomTextStyles.titleLargePrimarySemiBold), SizedBox(height: 7.v), Opacity(opacity: 0.7, child: Text("Help secure your account", style: CustomTextStyles.titleMediumPrimaryMedium16_3)), SizedBox(height: 18.v), Opacity(opacity: 0.7, child: Text("Username", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), _buildUsernameEditText(context), SizedBox(height: 11.v), Opacity(opacity: 0.7, child: Text("Password", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), _buildPasswordEditText(context), SizedBox(height: 11.v), Opacity(opacity: 0.7, child: Text("Confirm Password", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), _buildConfirmPasswordEditText(context), Spacer(), _buildNextButton(context), SizedBox(height: 38.v), Container(width: 185.h, margin: EdgeInsets.only(left: 78.h), child: RichText(text: TextSpan(children: [TextSpan(text: "Already have an account? ", style: CustomTextStyles.titleSmallff000000), TextSpan(text: "Sign In", style: CustomTextStyles.titleSmallff000000Bold.copyWith(decoration: TextDecoration.underline))]), textAlign: TextAlign.left))])))); } 
/// Section Widget
Widget _buildUsernameEditText(BuildContext context) { return CustomTextFormField(controller: usernameEditTextController); } 
/// Section Widget
Widget _buildPasswordEditText(BuildContext context) { return CustomTextFormField(controller: passwordEditTextController, obscureText: true, borderDecoration: TextFormFieldStyleHelper.fillGray); } 
/// Section Widget
Widget _buildConfirmPasswordEditText(BuildContext context) { return CustomTextFormField(controller: confirmPasswordEditTextController, textInputAction: TextInputAction.done, obscureText: true, borderDecoration: TextFormFieldStyleHelper.fillGray); } 
/// Section Widget
Widget _buildNextButton(BuildContext context) { return CustomElevatedButton(text: "Next", margin: EdgeInsets.only(left: 19.h, right: 20.h), alignment: Alignment.center); } 

/// Navigates back to the previous screen.
onTapImgArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
