import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class ForgotPasswordScreen extends StatelessWidget {ForgotPasswordScreen({Key? key}) : super(key: key);

TextEditingController usernameFieldController = TextEditingController();

TextEditingController emailFieldController = TextEditingController();

TextEditingController phoneNumberFieldController = TextEditingController();

TextEditingController passwordFieldController = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 26.h, vertical: 16.v), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(height: 54.v), Align(alignment: Alignment.center, child: Text("PURPOSE", style: CustomTextStyles.titleLargePrimaryMedium)), SizedBox(height: 35.v), CustomImageView(imagePath: ImageConstant.imgArrowLeft, height: 20.v, width: 11.h, margin: EdgeInsets.only(left: 4.h), onTap: () {onTapImgArrowLeft(context);}), SizedBox(height: 37.v), Padding(padding: EdgeInsets.only(left: 2.h), child: Text("Forgot Password", style: CustomTextStyles.titleLargePrimaryBlack)), SizedBox(height: 4.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 2.h), child: Text("Let’s help recover your account", style: CustomTextStyles.titleMediumPrimaryMedium16_3))), SizedBox(height: 18.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 2.h), child: Text("Username", style: theme.textTheme.titleSmall))), SizedBox(height: 5.v), _buildUsernameField(context), SizedBox(height: 11.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 2.h), child: Text("Email", style: theme.textTheme.titleSmall))), SizedBox(height: 5.v), _buildEmailField(context), SizedBox(height: 11.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 2.h), child: Text("Phone Number", style: theme.textTheme.titleSmall))), SizedBox(height: 5.v), _buildPhoneNumberField(context), SizedBox(height: 13.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 2.h), child: Text("Last Remembered password", style: theme.textTheme.titleSmall))), SizedBox(height: 3.v), _buildPasswordField(context), Spacer(), _buildNextButton(context), SizedBox(height: 38.v), Container(width: 185.h, margin: EdgeInsets.only(left: 75.h), child: RichText(text: TextSpan(children: [TextSpan(text: "Already have an account? ", style: CustomTextStyles.titleSmallff000000), TextSpan(text: "Sign Up", style: CustomTextStyles.titleSmallff000000Bold.copyWith(decoration: TextDecoration.underline))]), textAlign: TextAlign.left))])))); } 
/// Section Widget
Widget _buildUsernameField(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 2.h), child: CustomTextFormField(controller: usernameFieldController)); } 
/// Section Widget
Widget _buildEmailField(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 2.h), child: CustomTextFormField(controller: emailFieldController, borderDecoration: TextFormFieldStyleHelper.fillGray)); } 
/// Section Widget
Widget _buildPhoneNumberField(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 2.h), child: CustomTextFormField(controller: phoneNumberFieldController, obscureText: true, borderDecoration: TextFormFieldStyleHelper.fillGray)); } 
/// Section Widget
Widget _buildPasswordField(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 2.h), child: CustomTextFormField(controller: passwordFieldController, textInputAction: TextInputAction.done, obscureText: true, borderDecoration: TextFormFieldStyleHelper.fillGray)); } 
/// Section Widget
Widget _buildNextButton(BuildContext context) { return CustomElevatedButton(text: "Next", margin: EdgeInsets.only(left: 20.h, right: 21.h), onPressed: () {onTapNextButton(context);}, alignment: Alignment.center); } 

/// Navigates back to the previous screen.
onTapImgArrowLeft(BuildContext context) { Navigator.pop(context); } 
/// Navigates to the verificationScreen when the action is triggered.
onTapNextButton(BuildContext context) { Navigator.pushNamed(context, AppRoutes.verificationScreen); } 
 }
