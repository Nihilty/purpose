import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/custom_elevated_button.dart';
import 'package:purpv3/widgets/custom_icon_button.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';

class OnboardingTwoScreen extends StatelessWidget {
  const OnboardingTwoScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: 375.h,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgBlackBase21,
                height: 41.v,
                width: 375.h,
              ),
              SizedBox(height: 48.v),
              Padding(
                padding: EdgeInsets.only(
                  left: 34.h,
                  right: 65.h,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 165.v),
                      child: CustomIconButton(
                        height: 49.adaptSize,
                        width: 49.adaptSize,
                        padding: EdgeInsets.all(7.h),
                        decoration: IconButtonStyleHelper.fillCyan,
                        child: CustomImageView(
                          imagePath: ImageConstant.imgGroup4,
                        ),
                      ),
                    ),
                    Container(
                      height: 204.v,
                      width: 210.h,
                      margin: EdgeInsets.only(
                        left: 17.h,
                        bottom: 10.v,
                      ),
                      child: Stack(
                        alignment: Alignment.topRight,
                        children: [
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              height: 170.adaptSize,
                              width: 170.adaptSize,
                              padding: EdgeInsets.symmetric(
                                horizontal: 16.h,
                                vertical: 7.v,
                              ),
                              decoration: AppDecoration.fillTeal.copyWith(
                                borderRadius: BorderRadiusStyle.circleBorder85,
                              ),
                              child: CustomImageView(
                                imagePath: ImageConstant.img73,
                                height: 138.adaptSize,
                                width: 138.adaptSize,
                                alignment: Alignment.topCenter,
                              ),
                            ),
                          ),
                          CustomIconButton(
                            height: 49.adaptSize,
                            width: 49.adaptSize,
                            padding: EdgeInsets.all(8.h),
                            decoration: IconButtonStyleHelper.fillBlueGrayTL24,
                            alignment: Alignment.topRight,
                            child: CustomImageView(
                              imagePath: ImageConstant.imgGroup5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 15.v),
              Padding(
                padding: EdgeInsets.only(right: 65.h),
                child: CustomIconButton(
                  height: 49.adaptSize,
                  width: 49.adaptSize,
                  padding: EdgeInsets.all(9.h),
                  decoration: IconButtonStyleHelper.fillCyan,
                  alignment: Alignment.centerRight,
                  child: CustomImageView(
                    imagePath: ImageConstant.imgGroup4,
                  ),
                ),
              ),
              SizedBox(height: 47.v),
              Container(
                width: 285.h,
                margin: EdgeInsets.only(
                  left: 27.h,
                  right: 62.h,
                ),
                child: Text(
                  "Connect with industry professionals and colleuges",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.titleLargePrimarySemiBold,
                ),
              ),
              SizedBox(height: 4.v),
              _buildNext(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildNext(BuildContext context) {
    return SizedBox(
      height: 356.v,
      width: 375.h,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgRectangle287306x375,
            height: 306.v,
            width: 375.h,
            alignment: Alignment.bottomCenter,
            margin: EdgeInsets.only(bottom: 15.v),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: 26.h,
                vertical: 53.v,
              ),
              decoration: AppDecoration.gradientPrimaryToWhiteA,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomElevatedButton(
                    text: "Next",
                    buttonStyle: CustomButtonStyles.fillPrimaryTL10,
                  ),
                  SizedBox(height: 19.v),
                  CustomOutlinedButton(
                    height: 49.v,
                    text: "Skip",
                    buttonStyle: CustomButtonStyles.outlinePrimaryTL10,
                    buttonTextStyle: CustomTextStyles.titleMediumPrimary_1,
                  ),
                  SizedBox(height: 26.v),
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "Already have an account?",
                          style: CustomTextStyles.bodyMediumffffffff,
                        ),
                        TextSpan(
                          text: " ",
                        ),
                        TextSpan(
                          text: "Sign In",
                          style:
                              CustomTextStyles.titleSmallff000000Bold.copyWith(
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.left,
                  ),
                  SizedBox(height: 35.v),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Opacity(
              opacity: 0.7,
              child: SizedBox(
                width: 320.h,
                child: Text(
                  "Allowing you to make new leaps to your future is our Number one priority",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.titleMediumPrimaryMedium16_3,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
