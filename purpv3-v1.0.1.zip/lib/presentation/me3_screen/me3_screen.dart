import 'package:flutter/material.dart';import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class Me3Screen extends StatelessWidget {Me3Screen({Key? key}) : super(key: key);

TextEditingController editTextController = TextEditingController();

TextEditingController emailController = TextEditingController();

TextEditingController phoneNumberController = TextEditingController();

TextEditingController editTextController1 = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: SizedBox(width: 402.h, child: Column(children: [SizedBox(height: 81.v), Expanded(child: SingleChildScrollView(child: Container(margin: EdgeInsets.only(bottom: 64.v), padding: EdgeInsets.symmetric(horizontal: 30.h), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Align(alignment: Alignment.center, child: Text("Profile", style: CustomTextStyles.displaySmall34)), SizedBox(height: 39.v), Align(alignment: Alignment.center, child: Container(margin: EdgeInsets.symmetric(horizontal: 83.h), padding: EdgeInsets.symmetric(horizontal: 33.h, vertical: 38.v), decoration: AppDecoration.outlinePrimary2.copyWith(borderRadius: BorderRadiusStyle.circleBorder88), child: Container(margin: EdgeInsets.only(right: 2.h), padding: EdgeInsets.symmetric(horizontal: 15.h, vertical: 5.v), decoration: BoxDecoration(image: DecorationImage(image: fs.Svg(ImageConstant.imgGroup106), fit: BoxFit.cover)), child: Column(children: [SizedBox(height: 20.v), Container(height: 65.v, width: 72.h, padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 12.v), decoration: BoxDecoration(borderRadius: BorderRadiusStyle.roundedBorder27), child: CustomImageView(imagePath: ImageConstant.imgSolarGalleryE, height: 39.adaptSize, width: 39.adaptSize, alignment: Alignment.topCenter))])))), SizedBox(height: 40.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 7.h), child: Text("Let’s help edit your account", style: CustomTextStyles.titleMediumPrimaryMedium16_3))), SizedBox(height: 21.v), _buildEditText1(context), SizedBox(height: 13.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 7.h), child: Text("Email", style: theme.textTheme.titleSmall))), SizedBox(height: 5.v), _buildEmail(context), SizedBox(height: 12.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 7.h), child: Text("Phone Number", style: theme.textTheme.titleSmall))), SizedBox(height: 6.v), _buildPhoneNumber(context), SizedBox(height: 18.v), Opacity(opacity: 0.7, child: Padding(padding: EdgeInsets.only(left: 7.h), child: Text("Bio", style: theme.textTheme.titleSmall))), SizedBox(height: 5.v), _buildEditText2(context), SizedBox(height: 52.v), _buildSave(context)]))))])))); } 
/// Section Widget
Widget _buildEditText(BuildContext context) { return CustomTextFormField(width: 335.h, controller: editTextController, alignment: Alignment.bottomCenter); } 
/// Section Widget
Widget _buildEditText1(BuildContext context) { return Container(height: 73.v, width: 335.h, margin: EdgeInsets.only(left: 7.h), child: Stack(alignment: Alignment.bottomCenter, children: [Align(alignment: Alignment.topLeft, child: Opacity(opacity: 0.7, child: SizedBox(width: 40.h, child: Text("Username", maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.titleSmall)))), _buildEditText(context)])); } 
/// Section Widget
Widget _buildEmail(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 7.h), child: CustomTextFormField(controller: emailController, borderDecoration: TextFormFieldStyleHelper.fillGray)); } 
/// Section Widget
Widget _buildPhoneNumber(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 7.h), child: CustomTextFormField(controller: phoneNumberController, borderDecoration: TextFormFieldStyleHelper.fillGray)); } 
/// Section Widget
Widget _buildEditText2(BuildContext context) { return Padding(padding: EdgeInsets.only(left: 7.h), child: CustomTextFormField(controller: editTextController1, textInputAction: TextInputAction.done, borderDecoration: TextFormFieldStyleHelper.fillGray)); } 
/// Section Widget
Widget _buildSave(BuildContext context) { return CustomElevatedButton(text: "Save", margin: EdgeInsets.only(left: 16.h, right: 5.h), buttonStyle: CustomButtonStyles.fillPrimaryTL10, onPressed: () {onTapSave(context);}, alignment: Alignment.center); } 
/// Navigates to the me2Screen when the action is triggered.
onTapSave(BuildContext context) { Navigator.pushNamed(context, AppRoutes.me2Screen); } 
 }
