import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/custom_radio_button.dart';

// ignore_for_file: must_be_immutable
class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key})
      : super(
          key: key,
        );

  @override
  ProfilePageState createState() => ProfilePageState();
}

class ProfilePageState extends State<ProfilePage>
    with AutomaticKeepAliveClientMixin<ProfilePage> {
  String radioGroup = "";

  String radioGroup1 = "";

  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.onError,
        body: Container(
          width: double.maxFinite,
          margin: EdgeInsets.only(top: 47.v),
          decoration: AppDecoration.outlineWhiteA700,
          child: Column(
            children: [
              SizedBox(height: 28.v),
              _buildBotanyAndTaxonomySection(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBotanyAndTaxonomySection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 46.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 10.h),
            child: Text(
              "Your Enrolled Courses",
              style: CustomTextStyles.titleMediumBluegray800,
            ),
          ),
          SizedBox(height: 15.v),
          Padding(
            padding: EdgeInsets.only(left: 10.h),
            child: CustomRadioButton(
              text: "Botany and Taxonomy",
              value: "Botany and Taxonomy",
              groupValue: radioGroup,
              onChange: (value) {
                radioGroup = value;
              },
            ),
          ),
          SizedBox(height: 2.v),
          Padding(
            padding: EdgeInsets.only(left: 30.h),
            child: Text(
              "02 . 01 . 2019",
              style: CustomTextStyles.labelLargeErrorContainer,
            ),
          ),
          SizedBox(height: 13.v),
          Container(
            padding: EdgeInsets.symmetric(vertical: 10.v),
            decoration: AppDecoration.outlineSecondaryContainer.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder3,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: CustomImageView(
                    imagePath: ImageConstant.imgRectangle2,
                    height: 300.v,
                    width: 146.h,
                    radius: BorderRadius.circular(
                      3.h,
                    ),
                    margin: EdgeInsets.only(right: 5.h),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 5.h),
                  child: Column(
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle21,
                        height: 145.v,
                        width: 146.h,
                        radius: BorderRadius.circular(
                          3.h,
                        ),
                      ),
                      SizedBox(height: 10.v),
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle22,
                        height: 145.v,
                        width: 146.h,
                        radius: BorderRadius.circular(
                          3.h,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 19.v),
          Padding(
            padding: EdgeInsets.only(left: 10.h),
            child: CustomRadioButton(
              text: "CSE Basics ",
              value: "CSE Basics ",
              groupValue: radioGroup1,
              onChange: (value) {
                radioGroup1 = value;
              },
            ),
          ),
          SizedBox(height: 4.v),
          Padding(
            padding: EdgeInsets.only(left: 30.h),
            child: Text(
              "02 . 01 . 2019",
              style: CustomTextStyles.labelLargeErrorContainer,
            ),
          ),
        ],
      ),
    );
  }
}
