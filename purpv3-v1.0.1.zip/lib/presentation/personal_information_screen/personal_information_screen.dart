import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';import 'package:purpv3/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class PersonalInformationScreen extends StatelessWidget {PersonalInformationScreen({Key? key}) : super(key: key);

TextEditingController fullNameController = TextEditingController();

TextEditingController emailController = TextEditingController();

TextEditingController dateOfBirthController = TextEditingController();

TextEditingController editTextController = TextEditingController();

TextEditingController editTextController1 = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 19.h, vertical: 8.v), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(height: 50.v), Align(alignment: Alignment.center, child: Text("PURPOSE", style: CustomTextStyles.titleLargePrimaryMedium)), SizedBox(height: 38.v), CustomImageView(imagePath: ImageConstant.imgArrowLeft, height: 20.v, width: 11.h, margin: EdgeInsets.only(left: 2.h), onTap: () {onTapImgArrowLeft(context);}), SizedBox(height: 34.v), Text("Personal Information", style: CustomTextStyles.titleLargePrimarySemiBold), SizedBox(height: 7.v), Opacity(opacity: 0.7, child: Text("Please fill the following", style: CustomTextStyles.titleMediumPrimaryMedium16_3)), SizedBox(height: 18.v), Opacity(opacity: 0.7, child: Text("Full name", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), _buildFullName(context), SizedBox(height: 11.v), Opacity(opacity: 0.7, child: Text("Email Address", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), _buildEmail(context), SizedBox(height: 11.v), _buildDateOfBirthRow(context), SizedBox(height: 11.v), _buildAboutRow(context), SizedBox(height: 5.v), _buildEditText(context), SizedBox(height: 70.v), _buildNextButton(context), SizedBox(height: 38.v), Container(width: 185.h, margin: EdgeInsets.only(left: 78.h), child: RichText(text: TextSpan(children: [TextSpan(text: "Already have an account? ", style: CustomTextStyles.titleSmallff000000), TextSpan(text: "Sign In", style: CustomTextStyles.titleSmallff000000Bold.copyWith(decoration: TextDecoration.underline))]), textAlign: TextAlign.left))])))); } 
/// Section Widget
Widget _buildFullName(BuildContext context) { return CustomTextFormField(controller: fullNameController); } 
/// Section Widget
Widget _buildEmail(BuildContext context) { return CustomTextFormField(controller: emailController, borderDecoration: TextFormFieldStyleHelper.fillGray); } 
/// Section Widget
Widget _buildDateOfBirthColumn(BuildContext context) { return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Opacity(opacity: 0.7, child: Text("Date of birth", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), CustomTextFormField(width: 147.h, controller: dateOfBirthController, borderDecoration: TextFormFieldStyleHelper.fillGray)]); } 
/// Section Widget
Widget _buildGenderColumn(BuildContext context) { return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Opacity(opacity: 0.7, child: Text("Gender", style: theme.textTheme.titleSmall)), SizedBox(height: 5.v), CustomTextFormField(width: 147.h, controller: editTextController, borderDecoration: TextFormFieldStyleHelper.fillGray)]); } 
/// Section Widget
Widget _buildDateOfBirthRow(BuildContext context) { return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [_buildDateOfBirthColumn(context), _buildGenderColumn(context)]); } 
/// Section Widget
Widget _buildAboutRow(BuildContext context) { return Padding(padding: EdgeInsets.only(right: 19.h), child: Row(children: [Opacity(opacity: 0.7, child: Text("About", style: theme.textTheme.titleSmall)), Spacer(flex: 28), CustomImageView(imagePath: ImageConstant.imgFavoritePrimary, height: 8.adaptSize, width: 8.adaptSize, margin: EdgeInsets.only(top: 5.v, bottom: 6.v)), Spacer(flex: 71), CustomImageView(imagePath: ImageConstant.imgFavoritePrimary, height: 8.adaptSize, width: 8.adaptSize, margin: EdgeInsets.only(top: 5.v, bottom: 6.v))])); } 
/// Section Widget
Widget _buildEditText(BuildContext context) { return CustomTextFormField(controller: editTextController1, textInputAction: TextInputAction.done, borderDecoration: TextFormFieldStyleHelper.fillGray); } 
/// Section Widget
Widget _buildNextButton(BuildContext context) { return CustomElevatedButton(text: "Next", margin: EdgeInsets.symmetric(horizontal: 19.h), alignment: Alignment.center); } 

/// Navigates back to the previous screen.
onTapImgArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
