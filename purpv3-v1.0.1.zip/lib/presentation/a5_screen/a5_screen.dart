import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';

class A5Screen extends StatelessWidget {
  A5Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 29.h,
            top: 88.v,
            right: 29.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: 332.h,
                  margin: EdgeInsets.only(left: 24.h),
                  child: Text(
                    "Is your gender identity different from your biological sex?",
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.headlineLarge,
                  ),
                ),
              ),
              SizedBox(height: 84.v),
              CustomOutlinedButton(
                width: 159.h,
                text: "Yes",
                margin: EdgeInsets.only(left: 40.h),
              ),
              SizedBox(height: 41.v),
              CustomOutlinedButton(
                width: 159.h,
                text: "No",
                margin: EdgeInsets.only(left: 40.h),
              ),
              SizedBox(height: 41.v),
              CustomOutlinedButton(
                width: 197.h,
                text: "prefer not to say",
                margin: EdgeInsets.only(left: 40.h),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
