import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';class WelcomeScreen extends StatelessWidget {const WelcomeScreen({Key? key}) : super(key: key);

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 46.h, vertical: 106.v), child: Column(children: [Text("PURPOSE", style: CustomTextStyles.titleLargePrimaryMedium), Spacer(flex: 45), CustomImageView(imagePath: ImageConstant.imgEllipse8, height: 183.adaptSize, width: 183.adaptSize, radius: BorderRadius.circular(91.h)), SizedBox(height: 21.v), Text("Welcome Back", style: CustomTextStyles.titleLargePrimarySemiBold), Text("Charlie!!!", style: CustomTextStyles.titleLargePrimarySemiBold), SizedBox(height: 23.v), CustomElevatedButton(text: "Continue", onPressed: () {onTapContinue(context);}), Spacer(flex: 54)])))); } 
/// Navigates to the profileOneScreen when the action is triggered.
onTapContinue(BuildContext context) { Navigator.pushNamed(context, AppRoutes.profileOneScreen); } 
 }
