import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/presentation/homeone_page/homeone_page.dart';import 'package:purpv3/presentation/homepage_page/homepage_page.dart';import 'package:purpv3/presentation/profile_three_page/profile_three_page.dart';import 'package:purpv3/presentation/profile_two_page/profile_two_page.dart';import 'package:purpv3/widgets/app_bar/appbar_leading_image.dart';import 'package:purpv3/widgets/app_bar/custom_app_bar.dart';import 'package:purpv3/widgets/custom_bottom_bar.dart';class ProfileTwoTabContainerScreen extends StatefulWidget {const ProfileTwoTabContainerScreen({Key? key}) : super(key: key);

@override ProfileTwoTabContainerScreenState createState() =>  ProfileTwoTabContainerScreenState();

 }

// ignore_for_file: must_be_immutable
class ProfileTwoTabContainerScreenState extends State<ProfileTwoTabContainerScreen> with  TickerProviderStateMixin {late TabController tabviewController;

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override void initState() { super.initState(); tabviewController = TabController(length: 3, vsync: this); } 
@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(backgroundColor: theme.colorScheme.onError, appBar: _buildAppBar(context), body: SizedBox(height: 814.v, width: double.maxFinite, child: Stack(alignment: Alignment.topRight, children: [Align(alignment: Alignment.topRight, child: SizedBox(height: 228.v, width: 272.h, child: Stack(alignment: Alignment.topCenter, children: [CustomImageView(imagePath: ImageConstant.imgEllipse228x272, height: 228.v, width: 272.h, alignment: Alignment.center), Align(alignment: Alignment.topCenter, child: Padding(padding: EdgeInsets.fromLTRB(16.h, 58.v, 22.h, 79.v), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [CustomImageView(imagePath: ImageConstant.imgMobileGray50, height: 89.v, width: 92.h, margin: EdgeInsets.only(top: 2.v)), CustomImageView(imagePath: ImageConstant.imgGroup23, height: 22.v, width: 4.h, margin: EdgeInsets.only(bottom: 69.v))])))]))), CustomImageView(imagePath: ImageConstant.imgEllipse1, height: 196.v, width: 119.h, alignment: Alignment.topRight), Align(alignment: Alignment.topCenter, child: Padding(padding: EdgeInsets.only(left: 137.h, right: 131.h), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text("Charlie King", style: CustomTextStyles.titleLargeBold23), SizedBox(height: 4.v), Padding(padding: EdgeInsets.only(left: 38.h), child: Text("Student", style: CustomTextStyles.titleSmallWhiteA700))]))), _buildTabview(context), Container(margin: EdgeInsets.only(top: 47.v), height: 516.v, child: TabBarView(controller: tabviewController, children: [ProfileThreePage(), ProfileTwoPage(), ProfileTwoPage()]))])), bottomNavigationBar: _buildBottomBar(context))); } 
/// Section Widget
PreferredSizeWidget _buildAppBar(BuildContext context) { return CustomAppBar(height: 251.v, leadingWidth: double.maxFinite, leading: AppbarLeadingImage(imagePath: ImageConstant.imgArrowLeftWhiteA70024x24, margin: EdgeInsets.fromLTRB(23.h, 58.v, 367.h, 169.v), onTap: () {onTapArrowLeft(context);}), styleType: Style.bgFill); } 
/// Section Widget
Widget _buildTabview(BuildContext context) { return Container(height: 38.v, width: 337.h, margin: EdgeInsets.only(top: 9.v), child: TabBar(controller: tabviewController, labelPadding: EdgeInsets.zero, labelColor: appTheme.gray400, unselectedLabelColor: appTheme.gray40002, indicator: BoxDecoration(color: theme.colorScheme.onPrimary, borderRadius: BorderRadius.circular(19.h)), tabs: [Tab(child: Text("ARTICLES")), Tab(child: Text("SPECIES")), Tab(child: Text("SAVED"))])); } 
/// Section Widget
Widget _buildBottomBar(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.Home: return AppRoutes.homeonePage; case BottomBarEnum.Career: return AppRoutes.homepagePage; case BottomBarEnum.Chat: return "/"; case BottomBarEnum.Me: return "/"; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.homeonePage: return HomeonePage(); case AppRoutes.homepagePage: return HomepagePage(); default: return DefaultWidget();} } 

/// Navigates back to the previous screen.
onTapArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
