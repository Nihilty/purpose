import '../two_screen/widgets/mask_item_widget.dart';import 'package:carousel_slider/carousel_slider.dart';import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/widgets/app_bar/appbar_leading_image.dart';import 'package:purpv3/widgets/app_bar/appbar_trailing_image.dart';import 'package:purpv3/widgets/app_bar/custom_app_bar.dart';import 'package:purpv3/widgets/custom_elevated_button.dart';import 'package:smooth_page_indicator/smooth_page_indicator.dart';
// ignore_for_file: must_be_immutable
class TwoScreen extends StatelessWidget {TwoScreen({Key? key}) : super(key: key);

int sliderIndex = 1;

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(backgroundColor: appTheme.gray10001, appBar: _buildAppBar(context), body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 53.h), child: Column(children: [_buildMask(context), SizedBox(height: 37.v), SizedBox(height: 8.v, child: AnimatedSmoothIndicator(activeIndex: sliderIndex, count: 1, axisDirection: Axis.horizontal, effect: ScrollingDotsEffect(spacing: 12, activeDotColor: theme.colorScheme.primary, dotColor: appTheme.gray400, dotHeight: 8.v, dotWidth: 8.h))), SizedBox(height: 44.v), Text("Web Designer", style: CustomTextStyles.titleLargePTSansPrimary), SizedBox(height: 14.v), SizedBox(width: 81.h, child: Text(" Information Technology", maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: CustomTextStyles.bodyLargePTSansGray60001.copyWith(height: 1.01))), SizedBox(height: 28.v), Align(alignment: Alignment.centerLeft, child: Text("What", style: theme.textTheme.bodyLarge)), SizedBox(height: 1.v), Opacity(opacity: 0.5, child: Container(width: 299.h, margin: EdgeInsets.only(right: 8.h), child: Text("A web designer creates the layout and design of a website. In simple terms, a website designer makes a site look good.", maxLines: 4, overflow: TextOverflow.ellipsis, style: CustomTextStyles.bodyMediumPrimary.copyWith(height: 1.39)))), SizedBox(height: 20.v), Text("Similar", style: theme.textTheme.bodyLarge), SizedBox(height: 11.v), GestureDetector(onTap: () {onTapTxtUserExperience(context);}, child: Text("User Experience (UX) Designer", style: theme.textTheme.bodyMedium)), SizedBox(height: 11.v), GestureDetector(onTap: () {onTapTxtUserInterfaceUI(context);}, child: Text("User Interface (UI) Designer", style: theme.textTheme.bodyMedium)), SizedBox(height: 5.v)])), bottomNavigationBar: _buildLearnMore(context))); } 
/// Section Widget
PreferredSizeWidget _buildAppBar(BuildContext context) { return CustomAppBar(leadingWidth: 65.h, leading: AppbarLeadingImage(imagePath: ImageConstant.imgChevronLeft, margin: EdgeInsets.only(left: 41.h, top: 16.v, bottom: 16.v), onTap: () {onTapArrowLeft(context);}), actions: [AppbarTrailingImage(imagePath: ImageConstant.imgHeart, margin: EdgeInsets.fromLTRB(54.h, 16.v, 54.h, 20.v))]); } 
/// Section Widget
Widget _buildMask(BuildContext context) { return Padding(padding: EdgeInsets.symmetric(horizontal: 33.h), child: CarouselSlider.builder(options: CarouselOptions(height: 241.adaptSize, initialPage: 0, autoPlay: true, viewportFraction: 1.0, enableInfiniteScroll: false, scrollDirection: Axis.horizontal, onPageChanged: (index, reason) {sliderIndex = index;}), itemCount: 1, itemBuilder: (context, index, realIndex) {return MaskItemWidget();})); } 
/// Section Widget
Widget _buildLearnMore(BuildContext context) { return CustomElevatedButton(height: 70.v, text: "Learn  More", margin: EdgeInsets.only(left: 50.h, right: 50.h, bottom: 41.v), buttonStyle: CustomButtonStyles.fillPrimary, buttonTextStyle: CustomTextStyles.titleLargeGray10001, onPressed: () {onTapLearnMore(context);}); } 

/// Navigates back to the previous screen.
onTapArrowLeft(BuildContext context) { Navigator.pop(context); } 
/// Navigates to the k61Screen when the action is triggered.
onTapTxtUserExperience(BuildContext context) { Navigator.pushNamed(context, AppRoutes.k61Screen); } 
/// Navigates to the fourScreen when the action is triggered.
onTapTxtUserInterfaceUI(BuildContext context) { Navigator.pushNamed(context, AppRoutes.fourScreen); } 
/// Navigates to the fiveScreen when the action is triggered.
onTapLearnMore(BuildContext context) { Navigator.pushNamed(context, AppRoutes.fiveScreen); } 
 }
