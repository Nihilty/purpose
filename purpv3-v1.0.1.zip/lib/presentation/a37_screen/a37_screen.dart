import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';

class A37Screen extends StatelessWidget {
  A37Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 44.h,
            top: 97.v,
            right: 44.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 318.h,
                margin: EdgeInsets.only(right: 7.h),
                child: Text(
                  "Were the questions in this assessment easy to understand? ",
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.headlineLarge,
                ),
              ),
              SizedBox(height: 67.v),
              CustomOutlinedButton(
                width: 152.h,
                text: "yes",
              ),
              SizedBox(height: 34.v),
              CustomOutlinedButton(
                text: "prefer not to say",
                margin: EdgeInsets.only(right: 59.h),
              ),
              SizedBox(height: 40.v),
              CustomOutlinedButton(
                width: 156.h,
                text: "no",
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBarSection(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBarSection(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
