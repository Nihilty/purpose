import '../author_screen/widgets/userprofile1_item_widget.dart';import 'package:flutter/material.dart';import 'package:purpv3/core/app_export.dart';import 'package:purpv3/presentation/homeone_page/homeone_page.dart';import 'package:purpv3/presentation/homepage_page/homepage_page.dart';import 'package:purpv3/widgets/app_bar/appbar_leading_image.dart';import 'package:purpv3/widgets/app_bar/appbar_subtitle_one.dart';import 'package:purpv3/widgets/app_bar/appbar_trailing_image.dart';import 'package:purpv3/widgets/app_bar/custom_app_bar.dart';import 'package:purpv3/widgets/custom_bottom_bar.dart';
// ignore_for_file: must_be_immutable
class AuthorScreen extends StatelessWidget {AuthorScreen({Key? key}) : super(key: key);

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(appBar: _buildAppBar(context), body: Padding(padding: EdgeInsets.only(left: 42.h, right: 29.h), child: ListView.separated(physics: BouncingScrollPhysics(), shrinkWrap: true, separatorBuilder: (context, index) {return SizedBox(height: 33.v);}, itemCount: 3, itemBuilder: (context, index) {return Userprofile1ItemWidget();})), bottomNavigationBar: Padding(padding: EdgeInsets.only(left: 5.h), child: _buildBottomBar(context)))); } 
/// Section Widget
PreferredSizeWidget _buildAppBar(BuildContext context) { return CustomAppBar(leadingWidth: 31.h, leading: AppbarLeadingImage(imagePath: ImageConstant.imgArrowLeftPrimary, margin: EdgeInsets.only(left: 20.h, top: 19.v, bottom: 14.v), onTap: () {onTapArrowLeft(context);}), title: AppbarSubtitleOne(text: "Small Girl", margin: EdgeInsets.only(left: 41.h)), actions: [AppbarTrailingImage(imagePath: ImageConstant.imgGroupPrimary, margin: EdgeInsets.fromLTRB(28.h, 22.v, 28.h, 20.v))]); } 
/// Section Widget
Widget _buildBottomBar(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.Home: return AppRoutes.homeonePage; case BottomBarEnum.Career: return AppRoutes.homepagePage; case BottomBarEnum.Chat: return "/"; case BottomBarEnum.Me: return "/"; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.homeonePage: return HomeonePage(); case AppRoutes.homepagePage: return HomepagePage(); default: return DefaultWidget();} } 

/// Navigates back to the previous screen.
onTapArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
