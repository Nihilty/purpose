import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/widgets/custom_elevated_button.dart';

// ignore: must_be_immutable
class Userprofile1ItemWidget extends StatelessWidget {
  const Userprofile1ItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgEllipse189x89,
              height: 89.adaptSize,
              width: 89.adaptSize,
              radius: BorderRadius.circular(
                44.h,
              ),
            ),
            Spacer(
              flex: 38,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 26.v),
              child: Column(
                children: [
                  Text(
                    "1,132",
                    style: CustomTextStyles.titleMediumRobotoPrimary,
                  ),
                  SizedBox(height: 1.v),
                  Text(
                    "Posts",
                    style: CustomTextStyles.bodySmallRobotoPrimary,
                  ),
                ],
              ),
            ),
            Spacer(
              flex: 30,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 25.v),
              child: Column(
                children: [
                  Text(
                    "60K",
                    style: CustomTextStyles.titleMediumRobotoPrimary,
                  ),
                  SizedBox(height: 2.v),
                  Text(
                    "Followers",
                    style: CustomTextStyles.bodySmallRobotoPrimary,
                  ),
                ],
              ),
            ),
            Spacer(
              flex: 30,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 25.v),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 19.h),
                    child: Text(
                      "4",
                      style: CustomTextStyles.titleMediumRobotoPrimary,
                    ),
                  ),
                  SizedBox(height: 3.v),
                  Text(
                    "Following",
                    style: CustomTextStyles.bodySmallRobotoPrimary,
                  ),
                ],
              ),
            ),
          ],
        ),
        SizedBox(height: 7.v),
        Text(
          "Wallpaers 4k",
          style: CustomTextStyles.bodyMediumPrimary14,
        ),
        Text(
          "Find High Quality HD Pictures.",
          style: CustomTextStyles.bodyMediumPrimary14,
        ),
        Text(
          "www.wallpapers4k.com",
          style: CustomTextStyles.bodyMediumCyan90001,
        ),
        SizedBox(height: 23.v),
        Padding(
          padding: EdgeInsets.only(right: 12.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: CustomElevatedButton(
                  height: 25.v,
                  text: "+ Follow",
                  margin: EdgeInsets.only(
                    right: 15.h,
                    bottom: 1.v,
                  ),
                  buttonStyle: CustomButtonStyles.outlinePrimaryTL12,
                  buttonTextStyle: CustomTextStyles.labelMediumWhiteA700,
                ),
              ),
              Expanded(
                child: CustomElevatedButton(
                  height: 25.v,
                  text: "Message",
                  margin: EdgeInsets.only(left: 15.h),
                  buttonStyle: CustomButtonStyles.fillPrimaryTL10,
                  buttonTextStyle: CustomTextStyles.labelMediumWhiteA700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
