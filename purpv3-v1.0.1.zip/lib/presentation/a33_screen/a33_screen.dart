import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';
import 'package:purpv3/presentation/homeone_page/homeone_page.dart';
import 'package:purpv3/presentation/homepage_page/homepage_page.dart';
import 'package:purpv3/widgets/custom_bottom_bar.dart';
import 'package:purpv3/widgets/custom_outlined_button.dart';

class A33Screen extends StatelessWidget {
  A33Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 25.h,
            vertical: 98.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: 344.h,
                  margin: EdgeInsets.only(left: 18.h),
                  child: Text(
                    "How often do you eat sweet/sugary foods or desserts (other than fresh fruit)?",
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.headlineLarge,
                  ),
                ),
              ),
              Spacer(),
              _buildEverydayButton(context),
              SizedBox(height: 34.v),
              _buildFewDaysAWeekButton(context),
              SizedBox(height: 34.v),
              _buildOnceAWeekButton(context),
              SizedBox(height: 33.v),
              _buildRarelyButton(context),
              SizedBox(height: 23.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 17.h,
            right: 22.h,
          ),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEverydayButton(BuildContext context) {
    return CustomOutlinedButton(
      width: 220.h,
      text: "everyday",
      margin: EdgeInsets.only(left: 14.h),
    );
  }

  /// Section Widget
  Widget _buildFewDaysAWeekButton(BuildContext context) {
    return CustomOutlinedButton(
      text: "few days a week",
      margin: EdgeInsets.only(
        left: 14.h,
        right: 81.h,
      ),
    );
  }

  /// Section Widget
  Widget _buildOnceAWeekButton(BuildContext context) {
    return CustomOutlinedButton(
      width: 220.h,
      text: "once a week",
      margin: EdgeInsets.only(left: 14.h),
    );
  }

  /// Section Widget
  Widget _buildRarelyButton(BuildContext context) {
    return CustomOutlinedButton(
      width: 156.h,
      text: "rarely",
      margin: EdgeInsets.only(left: 14.h),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.homeonePage;
      case BottomBarEnum.Career:
        return AppRoutes.homepagePage;
      case BottomBarEnum.Chat:
        return "/";
      case BottomBarEnum.Me:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.homeonePage:
        return HomeonePage();
      case AppRoutes.homepagePage:
        return HomepagePage();
      default:
        return DefaultWidget();
    }
  }
}
