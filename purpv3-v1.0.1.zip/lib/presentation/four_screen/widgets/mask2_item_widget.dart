import 'package:flutter/material.dart';
import 'package:purpv3/core/app_export.dart';

// ignore: must_be_immutable
class Mask2ItemWidget extends StatelessWidget {
  const Mask2ItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 241.adaptSize,
      width: 241.adaptSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgImage2241x241,
            height: 241.adaptSize,
            width: 241.adaptSize,
            radius: BorderRadius.circular(
              120.h,
            ),
            alignment: Alignment.center,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgImage31,
            height: 241.adaptSize,
            width: 241.adaptSize,
            radius: BorderRadius.circular(
              120.h,
            ),
            alignment: Alignment.center,
          ),
        ],
      ),
    );
  }
}
