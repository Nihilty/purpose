class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // a2 images
  static String imgRectangle330 = '$imagePath/img_rectangle_330.png';

  // assessment images
  static String imgRectangle329 = '$imagePath/img_rectangle_329.png';

  // a39 images
  static String imgImage14 = '$imagePath/img_image_14.png';

  // me1 One images
  static String imgGgProfile = '$imagePath/img_gg_profile.svg';

  static String imgIcons8Buy = '$imagePath/img_icons8_buy.svg';

  static String imgArrowLeftWhiteA700 =
      '$imagePath/img_arrow_left_white_a700.svg';

  static String imgIcOutlineStickyNote2 =
      '$imagePath/img_ic_outline_sticky_note_2.svg';

  static String imgWhhSecurityalt = '$imagePath/img_whh_securityalt.svg';

  static String imgArrow1 = '$imagePath/img_arrow_1.svg';

  static String imgImage11 = '$imagePath/img_image_11.png';

  static String imgImage10 = '$imagePath/img_image_10.png';

  // me2 images
  static String imgMobile = '$imagePath/img_mobile.svg';

  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

  // me3 images
  static String imgGroup106 = '$imagePath/img_group_106.svg';

  static String imgSolarGalleryE = '$imagePath/img_solar_gallery_e.svg';

  // pageOne images
  static String imgLogoPrimary = '$imagePath/img_logo_primary.svg';

  // homeOne One images
  static String imgLock = '$imagePath/img_lock.svg';

  static String imgRectangle317 = '$imagePath/img_rectangle_317.png';

  // SPLASH images
  static String imgLogo = '$imagePath/img_logo.svg';

  static String imgPerson1 = '$imagePath/img_person1.svg';

  // ONBOARDING One images
  static String imgRectangle287 = '$imagePath/img_rectangle_287.png';

  // ONBOARDING Two images
  static String img73 = '$imagePath/img_73.png';

  static String imgRectangle287306x375 =
      '$imagePath/img_rectangle_287_306x375.png';

  // ONBOARDING Three images
  static String imgGroup118 = '$imagePath/img_group_118.png';

  static String imgGroup117 = '$imagePath/img_group_117.png';

  static String imgRectangle288 = '$imagePath/img_rectangle_288.png';

  // Profile images
  static String imgRectangle2 = '$imagePath/img_rectangle_2.png';

  static String imgRectangle21 = '$imagePath/img_rectangle_2_1.png';

  static String imgRectangle22 = '$imagePath/img_rectangle_2_2.png';

  // Profile - Tab Container images
  static String imgEllipse = '$imagePath/img_ellipse.png';

  static String imgEllipse196x119 = '$imagePath/img_ellipse_196x119.png';

  // Profile Three images
  static String imgRectangle218 = '$imagePath/img_rectangle_2_18.png';

  // Profile Two - Tab Container images
  static String imgEllipse228x272 = '$imagePath/img_ellipse_228x272.png';

  static String imgEllipse1 = '$imagePath/img_ellipse_1.png';

  // Profile One images
  static String imgSettingsPrimary56x57 =
      '$imagePath/img_settings_primary_56x57.svg';

  static String imgFrame31 = '$imagePath/img_frame_31.png';

  static String imgImage13135x115 = '$imagePath/img_image_13_135x115.png';

  static String imgArrowRightOnprimary =
      '$imagePath/img_arrow_right_onprimary.svg';

  static String imgFrame49 = '$imagePath/img_frame_49.svg';

  // Homepage images
  static String imgEllipse81x168 = '$imagePath/img_ellipse_81x168.png';

  static String imgEllipse124x75 = '$imagePath/img_ellipse_124x75.png';

  static String imgFace1 = '$imagePath/img_face1.svg';

  static String imgGroup = '$imagePath/img_group.svg';

  static String imgRectangle44 = '$imagePath/img_rectangle_4_4.png';

  static String imgRectangle44160x299 =
      '$imagePath/img_rectangle_4_4_160x299.png';

  static String imgRectangle25 = '$imagePath/img_rectangle_2_5.png';

  static String imgRectangle27 = '$imagePath/img_rectangle_2_7.png';

  static String imgRectangle2144x126 = '$imagePath/img_rectangle_2_144x126.png';

  static String imgRectangle28 = '$imagePath/img_rectangle_2_8.png';

  static String imgRectangle26 = '$imagePath/img_rectangle_2_6.png';

  static String imgGroup907 = '$imagePath/img_group_907.png';

  static String imgNavHomePrimary = '$imagePath/img_nav_home_primary.svg';

  static String imgCloseWhiteA700 = '$imagePath/img_close_white_a700.svg';

  static String imgNavProfile = '$imagePath/img_nav_profile.svg';

  // One images
  static String imgImage2 = '$imagePath/img_image_2.png';

  static String imgImage2124x128 = '$imagePath/img_image_2_124x128.png';

  static String imgUnsplashMk7d4ucfmg =
      '$imagePath/img_unsplash_mk7d_4ucfmg.png';

  static String imgImage21 = '$imagePath/img_image_2_1.png';

  // Two images
  static String imgImage3 = '$imagePath/img_image_3.png';

  // 3  images
  static String imgImage3241x241 = '$imagePath/img_image_3_241x241.png';

  // Four images
  static String imgImage31 = '$imagePath/img_image_3_1.png';

  // homeOne Two images
  static String imgCarbonQuery = '$imagePath/img_carbon_query.svg';

  // CHAT images
  static String imgEllipse31 = '$imagePath/img_ellipse_3_1.png';

  static String imgRectangle1 = '$imagePath/img_rectangle_1.svg';

  static String imgPlus = '$imagePath/img_plus.svg';

  static String imgSave = '$imagePath/img_save.svg';

  // CHAT LIST images
  static String imgSearch = '$imagePath/img_search.svg';

  static String imgUnsplashFiq0tet6llw =
      '$imagePath/img_unsplash_fiq0tet6llw.png';

  static String imgUnsplashNptlmg6jqdo =
      '$imagePath/img_unsplash_nptlmg6jqdo.png';

  static String imgUnsplashYbrAwm1hq4 =
      '$imagePath/img_unsplash_ybr_awm1hq4.png';

  static String imgUnsplashFqgi8adBsg =
      '$imagePath/img_unsplash_fqgi8ad_bsg.png';

  static String imgUnsplashIni8gnms190 =
      '$imagePath/img_unsplash_ini8gnms190.png';

  static String imgUnsplashFbanijhrol4 =
      '$imagePath/img_unsplash_fbanijhrol4.png';

  static String imgUnsplashPy8f6Hrn5o =
      '$imagePath/img_unsplash_py8f6_hrn5o.png';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgUnsplashCysrncvxe44 =
      '$imagePath/img_unsplash_cysrncvxe44.png';

  static String imgUnsplash6anudmpilw4 =
      '$imagePath/img_unsplash_6anudmpilw4.png';

  static String imgOffer = '$imagePath/img_offer.svg';

  static String imgUnsplashVghmxnd5a0i =
      '$imagePath/img_unsplash_vghmxnd5a0i.png';

  static String imgUnsplashLi7jb1925j0 =
      '$imagePath/img_unsplash_li7jb1925j0.png';

  static String imgSaveWhiteA700 = '$imagePath/img_save_white_a700.svg';

  // Articles images
  static String imgEllipse140x182 = '$imagePath/img_ellipse_140x182.png';

  static String imgEllipse147x71 = '$imagePath/img_ellipse_147x71.png';

  static String imgEllipse3128x28 = '$imagePath/img_ellipse_3_1_28x28.png';

  static String imgShare2 = '$imagePath/img_share_2.svg';

  static String imgRectangle221 = '$imagePath/img_rectangle_2_2_1.png';

  static String imgBookmarkRedA400 = '$imagePath/img_bookmark_red_a400.svg';

  static String imgRectangle218145x331 =
      '$imagePath/img_rectangle_2_18_145x331.png';

  // Detail Articles images
  static String imgRectangle = '$imagePath/img_rectangle.png';

  static String imgFavorite = '$imagePath/img_favorite.svg';

  static String imgEllipse3 = '$imagePath/img_ellipse_3.png';

  // Author  images
  static String imgArrowLeftPrimary = '$imagePath/img_arrow_left_primary.svg';

  static String imgGroupPrimary = '$imagePath/img_group_primary.svg';

  static String imgEllipse189x89 = '$imagePath/img_ellipse_1_89x89.png';

  static String imgEllipse311 = '$imagePath/img_ellipse_3_1_1.png';

  static String imgRectangle222 = '$imagePath/img_rectangle_2_2_2.png';

  static String imgRectangle2181 = '$imagePath/img_rectangle_2_18_1.png';

  // Five images
  static String imgRectangle299 = '$imagePath/img_rectangle_299.png';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgMap = '$imagePath/img_map.svg';

  // Eight images
  static String imgImage23 = '$imagePath/img_image_2_3.png';

  static String imgUnsplashMk7d4ucfmg128x128 =
      '$imagePath/img_unsplash_mk7d_4ucfmg_128x128.png';

  static String imgImage24 = '$imagePath/img_image_2_4.png';

  // pageOne One images
  static String imgLogoWhiteA700 = '$imagePath/img_logo_white_a700.svg';

  // SIGN UP images
  static String imgGroup73 = '$imagePath/img_group_73.svg';

  static String imgTelevision = '$imagePath/img_television.svg';

  static String imgCloseYellow600 = '$imagePath/img_close_yellow_600.svg';

  static String imgTelevisionWhiteA700 =
      '$imagePath/img_television_white_a700.svg';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgCloseRed700 = '$imagePath/img_close_red_700.svg';

  // PERSONAL INFORMATION images
  static String imgFavoritePrimary = '$imagePath/img_favorite_primary.svg';

  // Six images
  static String imgGroup203 = '$imagePath/img_group_203.svg';

  static String imgSeeHowMuchYou = '$imagePath/img_see_how_much_you.svg';

  static String imgRectangle304Stroke =
      '$imagePath/img_rectangle_304_stroke.svg';

  static String imgCareerMilestone = '$imagePath/img_career_milestone.svg';

  static String imgFrame = '$imagePath/img_frame.svg';

  static String imgSettingsPrimary10x39 =
      '$imagePath/img_settings_primary_10x39.svg';

  static String imgLinkedin = '$imagePath/img_linkedin.svg';

  static String imgSettingsPrimary10x45 =
      '$imagePath/img_settings_primary_10x45.svg';

  static String imgExploreAllPathways =
      '$imagePath/img_explore_all_pathways.svg';

  static String imgGetIntoYourDream = '$imagePath/img_get_into_your_dream.svg';

  static String imgThumbsUpPrimary = '$imagePath/img_thumbs_up_primary.svg';

  // Nine images
  static String imgImage32 = '$imagePath/img_image_3_2.png';

  static String imgImage25 = '$imagePath/img_image_2_5.png';

  static String imgUnsplashMk7d4ucfmg1 =
      '$imagePath/img_unsplash_mk7d_4ucfmg_1.png';

  static String imgImage26 = '$imagePath/img_image_2_6.png';

  static String imgImage4 = '$imagePath/img_image_4.png';

  // Seven images
  static String imgChevronLeftPrimary =
      '$imagePath/img_chevron_left_primary.svg';

  static String imgGroup149 = '$imagePath/img_group_149.svg';

  static String imgUserPrimary = '$imagePath/img_user_primary.svg';

  static String imgRefresh = '$imagePath/img_refresh.svg';

  // Common images
  static String imgHome = '$imagePath/img_home.svg';

  static String imgNavCareer = '$imagePath/img_nav_career.svg';

  static String imgClose = '$imagePath/img_close.svg';

  static String imgNavChat = '$imagePath/img_nav_chat.svg';

  static String imgNavMe = '$imagePath/img_nav_me.svg';

  static String imgRectangle341 = '$imagePath/img_rectangle_341.png';

  static String imgChevronLeft = '$imagePath/img_chevron_left.svg';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

  static String imgNavCareerBlueGray20002 =
      '$imagePath/img_nav_career_blue_gray_200_02.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgImage12 = '$imagePath/img_image_12.png';

  static String imgBlackBase21 = '$imagePath/img_black_base_2_1.png';

  static String imgGroup4 = '$imagePath/img_group_4.png';

  static String imgGroup5 = '$imagePath/img_group_5.png';

  static String imgArrowLeftWhiteA70024x24 =
      '$imagePath/img_arrow_left_white_a700_24x24.svg';

  static String imgMobileGray50 = '$imagePath/img_mobile_gray_50.svg';

  static String imgGroup23 = '$imagePath/img_group_2_3.svg';

  static String imgNavHomeOnprimary = '$imagePath/img_nav_home_onprimary.svg';

  static String imgCloseTealA400 = '$imagePath/img_close_teal_a400.svg';

  static String imgSettingsPrimary = '$imagePath/img_settings_primary.svg';

  static String imgLockOnprimarycontainer =
      '$imagePath/img_lock_onprimarycontainer.svg';

  static String imgRectangle22145x331 =
      '$imagePath/img_rectangle_2_2_145x331.png';

  static String imgImage13 = '$imagePath/img_image_13.png';

  static String imgEllipse32 = '$imagePath/img_ellipse_3_2.png';

  static String imgBookmark = '$imagePath/img_bookmark.svg';

  static String imgRewind = '$imagePath/img_rewind.svg';

  static String imgFilter = '$imagePath/img_filter.svg';

  static String imgImage2128x128 = '$imagePath/img_image_2_128x128.png';

  static String imgImage2125x128 = '$imagePath/img_image_2_125x128.png';

  static String imgHeart = '$imagePath/img_heart.svg';

  static String imgImage2241x241 = '$imagePath/img_image_2_241x241.png';

  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgImage22 = '$imagePath/img_image_2_2.png';

  static String imgImage3128x128 = '$imagePath/img_image_3_128x128.png';

  static String imgEllipse8 = '$imagePath/img_ellipse_8.png';

  static String imgArrowLeftPrimary24x24 =
      '$imagePath/img_arrow_left_primary_24x24.svg';

  static String imgHeartPrimary = '$imagePath/img_heart_primary.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
