import 'package:flutter/material.dart';
import 'package:purpv3/presentation/a2_screen/a2_screen.dart';
import 'package:purpv3/presentation/assessment_screen/assessment_screen.dart';
import 'package:purpv3/presentation/a3_screen/a3_screen.dart';
import 'package:purpv3/presentation/a4_screen/a4_screen.dart';
import 'package:purpv3/presentation/a5_screen/a5_screen.dart';
import 'package:purpv3/presentation/a6_screen/a6_screen.dart';
import 'package:purpv3/presentation/a7_screen/a7_screen.dart';
import 'package:purpv3/presentation/a8_screen/a8_screen.dart';
import 'package:purpv3/presentation/a9_screen/a9_screen.dart';
import 'package:purpv3/presentation/a10_screen/a10_screen.dart';
import 'package:purpv3/presentation/a11_screen/a11_screen.dart';
import 'package:purpv3/presentation/a12_screen/a12_screen.dart';
import 'package:purpv3/presentation/a13_screen/a13_screen.dart';
import 'package:purpv3/presentation/a14_screen/a14_screen.dart';
import 'package:purpv3/presentation/a15_screen/a15_screen.dart';
import 'package:purpv3/presentation/a16_screen/a16_screen.dart';
import 'package:purpv3/presentation/a17_screen/a17_screen.dart';
import 'package:purpv3/presentation/a18_screen/a18_screen.dart';
import 'package:purpv3/presentation/a19_screen/a19_screen.dart';
import 'package:purpv3/presentation/a20_screen/a20_screen.dart';
import 'package:purpv3/presentation/a21_screen/a21_screen.dart';
import 'package:purpv3/presentation/a22_screen/a22_screen.dart';
import 'package:purpv3/presentation/a23_screen/a23_screen.dart';
import 'package:purpv3/presentation/a24_screen/a24_screen.dart';
import 'package:purpv3/presentation/a25_screen/a25_screen.dart';
import 'package:purpv3/presentation/a26_screen/a26_screen.dart';
import 'package:purpv3/presentation/a27_screen/a27_screen.dart';
import 'package:purpv3/presentation/a28_screen/a28_screen.dart';
import 'package:purpv3/presentation/a29_screen/a29_screen.dart';
import 'package:purpv3/presentation/a30_screen/a30_screen.dart';
import 'package:purpv3/presentation/a31_screen/a31_screen.dart';
import 'package:purpv3/presentation/a32_screen/a32_screen.dart';
import 'package:purpv3/presentation/a33_screen/a33_screen.dart';
import 'package:purpv3/presentation/a34_screen/a34_screen.dart';
import 'package:purpv3/presentation/a35_screen/a35_screen.dart';
import 'package:purpv3/presentation/a36_screen/a36_screen.dart';
import 'package:purpv3/presentation/a37_screen/a37_screen.dart';
import 'package:purpv3/presentation/a38_screen/a38_screen.dart';
import 'package:purpv3/presentation/a39_screen/a39_screen.dart';
import 'package:purpv3/presentation/me1_one_screen/me1_one_screen.dart';
import 'package:purpv3/presentation/me2_screen/me2_screen.dart';
import 'package:purpv3/presentation/me3_screen/me3_screen.dart';
import 'package:purpv3/presentation/pageone_screen/pageone_screen.dart';
import 'package:purpv3/presentation/homeone_one_screen/homeone_one_screen.dart';
import 'package:purpv3/presentation/startpage_screen/startpage_screen.dart';
import 'package:purpv3/presentation/homeone_container_screen/homeone_container_screen.dart';
import 'package:purpv3/presentation/splash_screen/splash_screen.dart';
import 'package:purpv3/presentation/onboarding_one_screen/onboarding_one_screen.dart';
import 'package:purpv3/presentation/onboarding_two_screen/onboarding_two_screen.dart';
import 'package:purpv3/presentation/onboarding_three_screen/onboarding_three_screen.dart';
import 'package:purpv3/presentation/profile_tab_container_screen/profile_tab_container_screen.dart';
import 'package:purpv3/presentation/profile_two_tab_container_screen/profile_two_tab_container_screen.dart';
import 'package:purpv3/presentation/profile_one_screen/profile_one_screen.dart';
import 'package:purpv3/presentation/one_screen/one_screen.dart';
import 'package:purpv3/presentation/two_screen/two_screen.dart';
import 'package:purpv3/presentation/k61_screen/k61_screen.dart';
import 'package:purpv3/presentation/four_screen/four_screen.dart';
import 'package:purpv3/presentation/homeone_two_screen/homeone_two_screen.dart';
import 'package:purpv3/presentation/chat_screen/chat_screen.dart';
import 'package:purpv3/presentation/chat_list_screen/chat_list_screen.dart';
import 'package:purpv3/presentation/articles_screen/articles_screen.dart';
import 'package:purpv3/presentation/detail_articles_screen/detail_articles_screen.dart';
import 'package:purpv3/presentation/author_screen/author_screen.dart';
import 'package:purpv3/presentation/five_screen/five_screen.dart';
import 'package:purpv3/presentation/eight_screen/eight_screen.dart';
import 'package:purpv3/presentation/pageone_one_screen/pageone_one_screen.dart';
import 'package:purpv3/presentation/startpage_one_screen/startpage_one_screen.dart';
import 'package:purpv3/presentation/sign_in_screen/sign_in_screen.dart';
import 'package:purpv3/presentation/forgot_password_screen/forgot_password_screen.dart';
import 'package:purpv3/presentation/verification_screen/verification_screen.dart';
import 'package:purpv3/presentation/password_reset_screen/password_reset_screen.dart';
import 'package:purpv3/presentation/welcome_screen/welcome_screen.dart';
import 'package:purpv3/presentation/sign_up_screen/sign_up_screen.dart';
import 'package:purpv3/presentation/verification_one_screen/verification_one_screen.dart';
import 'package:purpv3/presentation/personal_information_screen/personal_information_screen.dart';
import 'package:purpv3/presentation/username_screen/username_screen.dart';
import 'package:purpv3/presentation/welcome_one_screen/welcome_one_screen.dart';
import 'package:purpv3/presentation/six_screen/six_screen.dart';
import 'package:purpv3/presentation/nine_screen/nine_screen.dart';
import 'package:purpv3/presentation/seven_screen/seven_screen.dart';
import 'package:purpv3/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String a2Screen = '/a2_screen';

  static const String assessmentScreen = '/assessment_screen';

  static const String a3Screen = '/a3_screen';

  static const String a4Screen = '/a4_screen';

  static const String a5Screen = '/a5_screen';

  static const String a6Screen = '/a6_screen';

  static const String a7Screen = '/a7_screen';

  static const String a8Screen = '/a8_screen';

  static const String a9Screen = '/a9_screen';

  static const String a10Screen = '/a10_screen';

  static const String a11Screen = '/a11_screen';

  static const String a12Screen = '/a12_screen';

  static const String a13Screen = '/a13_screen';

  static const String a14Screen = '/a14_screen';

  static const String a15Screen = '/a15_screen';

  static const String a16Screen = '/a16_screen';

  static const String a17Screen = '/a17_screen';

  static const String a18Screen = '/a18_screen';

  static const String a19Screen = '/a19_screen';

  static const String a20Screen = '/a20_screen';

  static const String a21Screen = '/a21_screen';

  static const String a22Screen = '/a22_screen';

  static const String a23Screen = '/a23_screen';

  static const String a24Screen = '/a24_screen';

  static const String a25Screen = '/a25_screen';

  static const String a26Screen = '/a26_screen';

  static const String a27Screen = '/a27_screen';

  static const String a28Screen = '/a28_screen';

  static const String a29Screen = '/a29_screen';

  static const String a30Screen = '/a30_screen';

  static const String a31Screen = '/a31_screen';

  static const String a32Screen = '/a32_screen';

  static const String a33Screen = '/a33_screen';

  static const String a34Screen = '/a34_screen';

  static const String a35Screen = '/a35_screen';

  static const String a36Screen = '/a36_screen';

  static const String a37Screen = '/a37_screen';

  static const String a38Screen = '/a38_screen';

  static const String a39Screen = '/a39_screen';

  static const String me1OneScreen = '/me1_one_screen';

  static const String me2Screen = '/me2_screen';

  static const String me3Screen = '/me3_screen';

  static const String pageoneScreen = '/pageone_screen';

  static const String homeoneOneScreen = '/homeone_one_screen';

  static const String startpageScreen = '/startpage_screen';

  static const String homeonePage = '/homeone_page';

  static const String homeoneContainerScreen = '/homeone_container_screen';

  static const String splashScreen = '/splash_screen';

  static const String onboardingOneScreen = '/onboarding_one_screen';

  static const String onboardingTwoScreen = '/onboarding_two_screen';

  static const String onboardingThreeScreen = '/onboarding_three_screen';

  static const String profilePage = '/profile_page';

  static const String profileTabContainerScreen =
      '/profile_tab_container_screen';

  static const String profileThreePage = '/profile_three_page';

  static const String profileTwoPage = '/profile_two_page';

  static const String profileTwoTabContainerScreen =
      '/profile_two_tab_container_screen';

  static const String profileOneScreen = '/profile_one_screen';

  static const String homepagePage = '/homepage_page';

  static const String oneScreen = '/one_screen';

  static const String twoScreen = '/two_screen';

  static const String k61Screen = '/k61_screen';

  static const String fourScreen = '/four_screen';

  static const String homeoneTwoScreen = '/homeone_two_screen';

  static const String chatScreen = '/chat_screen';

  static const String chatListScreen = '/chat_list_screen';

  static const String articlesScreen = '/articles_screen';

  static const String detailArticlesScreen = '/detail_articles_screen';

  static const String authorScreen = '/author_screen';

  static const String fiveScreen = '/five_screen';

  static const String eightScreen = '/eight_screen';

  static const String pageoneOneScreen = '/pageone_one_screen';

  static const String startpageOneScreen = '/startpage_one_screen';

  static const String signInScreen = '/sign_in_screen';

  static const String forgotPasswordScreen = '/forgot_password_screen';

  static const String verificationScreen = '/verification_screen';

  static const String passwordResetScreen = '/password_reset_screen';

  static const String welcomeScreen = '/welcome_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String verificationOneScreen = '/verification_one_screen';

  static const String personalInformationScreen =
      '/personal_information_screen';

  static const String usernameScreen = '/username_screen';

  static const String welcomeOneScreen = '/welcome_one_screen';

  static const String sixScreen = '/six_screen';

  static const String nineScreen = '/nine_screen';

  static const String sevenScreen = '/seven_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    a2Screen: (context) => A2Screen(),
    assessmentScreen: (context) => AssessmentScreen(),
    a3Screen: (context) => A3Screen(),
    a4Screen: (context) => A4Screen(),
    a5Screen: (context) => A5Screen(),
    a6Screen: (context) => A6Screen(),
    a7Screen: (context) => A7Screen(),
    a8Screen: (context) => A8Screen(),
    a9Screen: (context) => A9Screen(),
    a10Screen: (context) => A10Screen(),
    a11Screen: (context) => A11Screen(),
    a12Screen: (context) => A12Screen(),
    a13Screen: (context) => A13Screen(),
    a14Screen: (context) => A14Screen(),
    a15Screen: (context) => A15Screen(),
    a16Screen: (context) => A16Screen(),
    a17Screen: (context) => A17Screen(),
    a18Screen: (context) => A18Screen(),
    a19Screen: (context) => A19Screen(),
    a20Screen: (context) => A20Screen(),
    a21Screen: (context) => A21Screen(),
    a22Screen: (context) => A22Screen(),
    a23Screen: (context) => A23Screen(),
    a24Screen: (context) => A24Screen(),
    a25Screen: (context) => A25Screen(),
    a26Screen: (context) => A26Screen(),
    a27Screen: (context) => A27Screen(),
    a28Screen: (context) => A28Screen(),
    a29Screen: (context) => A29Screen(),
    a30Screen: (context) => A30Screen(),
    a31Screen: (context) => A31Screen(),
    a32Screen: (context) => A32Screen(),
    a33Screen: (context) => A33Screen(),
    a34Screen: (context) => A34Screen(),
    a35Screen: (context) => A35Screen(),
    a36Screen: (context) => A36Screen(),
    a37Screen: (context) => A37Screen(),
    a38Screen: (context) => A38Screen(),
    a39Screen: (context) => A39Screen(),
    me1OneScreen: (context) => Me1OneScreen(),
    me2Screen: (context) => Me2Screen(),
    me3Screen: (context) => Me3Screen(),
    pageoneScreen: (context) => PageoneScreen(),
    homeoneOneScreen: (context) => HomeoneOneScreen(),
    startpageScreen: (context) => StartpageScreen(),
    homeoneContainerScreen: (context) => HomeoneContainerScreen(),
    splashScreen: (context) => SplashScreen(),
    onboardingOneScreen: (context) => OnboardingOneScreen(),
    onboardingTwoScreen: (context) => OnboardingTwoScreen(),
    onboardingThreeScreen: (context) => OnboardingThreeScreen(),
    profileTabContainerScreen: (context) => ProfileTabContainerScreen(),
    profileTwoTabContainerScreen: (context) => ProfileTwoTabContainerScreen(),
    profileOneScreen: (context) => ProfileOneScreen(),
    oneScreen: (context) => OneScreen(),
    twoScreen: (context) => TwoScreen(),
    k61Screen: (context) => K61Screen(),
    fourScreen: (context) => FourScreen(),
    homeoneTwoScreen: (context) => HomeoneTwoScreen(),
    chatScreen: (context) => ChatScreen(),
    chatListScreen: (context) => ChatListScreen(),
    articlesScreen: (context) => ArticlesScreen(),
    detailArticlesScreen: (context) => DetailArticlesScreen(),
    authorScreen: (context) => AuthorScreen(),
    fiveScreen: (context) => FiveScreen(),
    eightScreen: (context) => EightScreen(),
    pageoneOneScreen: (context) => PageoneOneScreen(),
    startpageOneScreen: (context) => StartpageOneScreen(),
    signInScreen: (context) => SignInScreen(),
    forgotPasswordScreen: (context) => ForgotPasswordScreen(),
    verificationScreen: (context) => VerificationScreen(),
    passwordResetScreen: (context) => PasswordResetScreen(),
    welcomeScreen: (context) => WelcomeScreen(),
    signUpScreen: (context) => SignUpScreen(),
    verificationOneScreen: (context) => VerificationOneScreen(),
    personalInformationScreen: (context) => PersonalInformationScreen(),
    usernameScreen: (context) => UsernameScreen(),
    welcomeOneScreen: (context) => WelcomeOneScreen(),
    sixScreen: (context) => SixScreen(),
    nineScreen: (context) => NineScreen(),
    sevenScreen: (context) => SevenScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
